---
name: agentflow
description: AgentFlow 自进化AI Agent框架的MCP工具使用指南。AgentFlow提供38个工具（28个核心 + 10个扩展），覆盖目标管理、任务调度、上下文编译、技能进化、经验反馈、安全审计和监控仪表盘。当使用AgentFlow MCP服务器进行开发时，用于管理目标、执行任务、积累经验、进化技能。
license: MIT
---

# AgentFlow MCP 工具使用指南

## 概述

AgentFlow 是一个**自进化AI Agent框架**，提供38个MCP工具，分为7个模块。你与AgentFlow交互的质量，取决于你是否严格遵循「目标 → 任务 → 上下文 → 执行 → 汇报 → 经验」的工作流。

**核心原则：**
- **目标→任务驱动**：先创建目标，再拆解为任务，按序执行
- **上下文自动注入**：`claim_task` 成功时自动返回 `compiled_context`（无需额外调用 `get_task_context`）
- **智能经验引导**：`report_task_result` 返回 `experience_hint`，指导你是否需要上报经验
- **技能DNA进化**：经验积累 → 加权模式检测 → 规则进化（灰度验证）→ 能力增长
- **安全兜底**：五维健康检查 + Archive快照回滚 + 灰度发布自动回滚

> 📚 **参考文档**（按需加载，不要预加载）：
> - [🔧 工具参数参考](./reference/tools_reference.md) — 全部38个工具的完整参数定义
> - [📋 工作流示例](./reference/workflow_examples.md) — 完整JSON调用示例和场景演示

---

## ⚡ af 触发规则

当用户的消息以 **"af"** 开头时，表示使用 AgentFlow 系统：
1. **优先判断是否涉及任务系统**（目标/任务/执行/汇报）→ 走任务工作流
2. **否则一定走经验模式**（经验查询/修复追踪/反馈/进化）

---

## 📖 经验模式

当 af 触发且不涉及任务系统时，自动进入经验模式。

### 经验模式工具速查

| 分类 | 工具 |
|------|------|
| Fix Session | `query_fix_experience` → `report_fix_attempt` → `update_fix_attempt_label` → `close_fix_session` |
| 经验管理 | `report_experience`（上报） / `feedback_experience`（反馈） / `list_experiences` + `delete_experiences`（迭代清理） |
| 吐槽反馈 | `agent_complaint`（记录不满，severity: minor/frustrating/blocking） / `get_complaint_stats`（统计热点） |
| 进化审计 | `distill_and_evolve`（提炼进化） / `audit_skill_quality`（质量审查） |

> 📋 完整参数见 [工具参数参考](./reference/tools_reference.md)，JSON示例见 [工作流示例](./reference/workflow_examples.md)

### 经验模式核心流程

```
遇到问题 → query_fix_experience（获取session_id+历史经验）
  → 尝试修复 → report_fix_attempt（记录每次尝试）
  → 对经验反馈 feedback_experience（helpful/misleading/outdated）
  → 标记尝试 update_fix_attempt_label（correct/dead_end）
  → 关闭会话 close_fix_session（resolved/abandoned）
```

### 经验上报判断

**上报**：可复用模式/Bug修复（必填root_cause+solution）/性能安全发现/**外部MCP工具使用经验（必记）**
**不报**：太笼统的总结 / 日常操作 / 高度耦合无法复用的信息

### 经验反馈

负面反馈标签：`not_applicable` / `misleading` / `outdated` / `too_vague` / `wrong_root_cause` / `partial_match` / `duplicate_effort` / `context_mismatch`。累计≥3次 `misleading` 触发拉黑。

---

## 🛡️ 长上下文防护策略

当排查棘手问题时（多轮尝试、大量文件阅读、多方向排查），上下文快速膨胀会导致进度丢失。通过 **Fix Session + Checkpoint 双通道持久化** 防护。

**触发信号**（满足任一即启动）：3次以上排查尝试 / 5个以上文件阅读 / 3个以上排查方向 / 对话明显变长

**三步持久化：**
1. **创建Fix Session** — 开始排查时立即 `query_fix_experience` 获取 session_id
2. **排查一步记一步** — 每排查一个方向立即 `report_fix_attempt` + `update_fix_attempt_label`
3. **阶段性总结** — 感知上下文膨胀时做总结（含已排查方向+可疑线索+下一步建议），同时 `save_checkpoint`

**下一个Agent续接**：`claim_task` 恢复检查点 → 查看备注中的Fix Session ID → `query_fix_experience` 获取排查历史 → 从 `promising` 标记处继续

> 📋 完整的防护策略JSON示例见 [工作流示例](./reference/workflow_examples.md)

---

## ⛔ 关键规则（必须遵守）

1. **禁止不查状态就 `claim_task`** — 必须先 `get_dashboard`
2. **禁止盲目重试** — 分析错误信息再决定下一步
3. **没有任务先创建** — 不要反复 `claim_task` 期望任务凭空出现
4. **严格遵守工作流顺序**：目标 → 任务 → 领取 → 执行 → 汇报 → 经验
5. **工具连续失败2次立即停止** — 向用户报告，禁止无限循环
6. **禁止领取 running 任务** — 已有Agent在处理
7. **优先级**：interrupted > failed > blocked > pending
8. **依赖阻塞检测** — 只有running任务且其他都依赖它 → 退出Agent
9. **难度匹配领取** — 优先 difficulty ≤ 6，高难度（7-10）积累经验后再领取
10. **复杂任务可拆分** — 用 `split_task` 拆分为孙任务
11. **Review机制** — difficulty ≥ 7 的任务完成后建议创建 code_review 任务
12. **MCP工具经验必记** — 使用外部MCP工具必须上报 mcp_usage 经验
13. 🔴 **吐槽强制触发** — 满足以下任一条件时**必须**调用 `agent_complaint`：
    - 同一工具连续失败 ≥ 2 次
    - 任务状态变为 `blocked` 或 `failed`
    - `context_sufficient = false`（上下文不充分）
    - 某条经验被证明是误导性的（misleading）
    - 工具行为与文档描述不符
14. 🔴 **进化强制触发** — 满足以下任一条件时**必须**调用 `distill_and_evolve`：
    - 连续完成 ≥ 3 个相同 `skill_type` 的任务
    - `report_task_result` 返回中包含 `evolution_hint`（进化提示）
    - 上报了 severity=critical 的负经验
    - 当前 Skill 的 `pass_rate` 低于 50%

---

# 🚀 工作流

## 阶段一：理解工具架构

### 1.1 工具分层

- **第一层（28个）**：核心工具，连接即可用
- **第二层（10个）**：扩展工具，需先调用 `get_extended_tools` 解锁

### 1.2 模块概览

| 模块 | L1 | L2 | 用途 |
|------|----|----|------|
| 目标（Goal） | 5 | 0 | 目标增删改查 + 层级 + 进度 |
| 任务（Task） | 7 | 0 | 创建、领取、拆分、执行、汇报 |
| 上下文（Context） | 4 | 1 | 编译、规则、产出物、搜索 |
| 技能（Skill） | 2 | 2 | DNA管理 + 进化 |
| 进化（Evolution） | 6 | 4 | 经验、提炼、审计、经验管理 |
| 反馈（Feedback） | 2 | 0 | 吐槽 + 统计 |
| 仪表盘/安全 | 2 | 3 | 监控、健康、安全、回滚 |

### 1.3 预设技能

| 技能 | 适用场景 |
|------|----------|
| `go_crud` | Go CRUD开发（数据库/校验/并发） |
| `api_design` | API接口设计（RESTful/参数/错误码） |
| `auth_security` | 认证授权与安全 |
| `db_storage` | 数据库/存储层（Redis/SQLite） |
| `testing` | 测试开发（单元/集成/压力） |
| `code_review` | 代码评审（质量/规范/安全） |
| `project_lifecycle` | AI驱动的项目全生命周期管理（阶段推进/PhaseGate审批/Goal关联） |

---

## 阶段1.5：首次连接 — 状态检查（⚠️ 必须执行）

```
get_dashboard → 了解：有多少目标？多少任务？什么状态？
```

| 系统状态 | 行动 |
|----------|------|
| 没有目标 | → 创建目标 |
| 有目标没任务 | → 拆解任务 |
| 有 interrupted/failed/blocked 任务 | → **优先领取** |
| 有 pending 任务 | → 领取任务 |
| 只有 running 且其他都依赖它 | → **退出Agent或等待** |
| 全部完成 | → 检查目标状态，向用户汇报 |

---

## 阶段二：任务执行（标准工作流）

强制执行序列：
```
create_goal → create_tasks → claim_task(自动返回上下文) → [执行+进度更新] → report_task_result → [按experience_hint]report_experience
```

### 🔴 2.1 创建目标（必须）

每个任务必须归属目标。目标支持层级、阶段（phases）、优先级（1-10）和标签。

### 🔴 2.2 拆解为任务（必须）

每个任务必须指定 `skill_type` 和 `description`，推荐指定 `difficulty`（1-10，默认5）。

**难度评分（difficulty）：**

| 等级 | 描述 | 预估时间 |
|------|------|----------|
| 1-3 简单 | 单文件修改、标准CRUD、配置调整 | < 15分钟 |
| 4-6 中等 | 多文件协作、业务逻辑、状态管理 | 15-45分钟 |
| 7-9 困难 | 架构设计、并发控制、跨模块集成 | 45-90分钟 |
| 10 极难 | 核心重构、高性能优化、安全审计 | > 90分钟 |

支持 `dependencies`（任务间依赖，支持ID或标题引用，自动循环检测）、`prerequisites`（软约束前提）、`test_design`（测试设计）。

> 📋 完整参数见 [工具参数参考](./reference/tools_reference.md) 中 `create_tasks` 部分

### 🔴 2.3 领取任务（必须 — 原子操作）

**前置条件：** 已 `get_dashboard` 确认状态 + 有可领取任务 + 已评估难度匹配

**领取优先级（强制）：** interrupted > failed > blocked > pending。⛔ 禁止领取 running。

**上下文自动注入：** 领取成功后 `compiled_context` 自动包含全局规则、Skill DNA、相关经验、依赖摘要。收到后必须阅读规则和反模式部分再开始编码。

**心跳配置：** soft_timeout 25分钟（警告），hard_timeout 30分钟（强制中断释放）。任何MCP工具调用自动续期。

**错误处理：**

| 错误 | 处理 |
|------|------|
| no pending tasks | 立即停止，告知用户。有新需求走 create_goal → create_tasks |
| task not found | `list_tasks` 核实ID，最多重试1次 |
| lock conflict | 等2秒重试1次，仍失败则停止 |
| dependencies not met | `list_tasks` 查前置任务（仅1次），告知用户 |
| 连续失败2次 | **立即停止**，向用户报告 |

### 🟡 2.3.1 复杂任务拆分（按需）

**触发条件：** 涉及3+模块 / 需多种技能 / difficulty ≥ 7预估超30分钟 / 实际复杂度远超预期

使用 `split_task` 拆分为孙任务，孙任务继承父任务的goal_id和phase。只有当前领取者才能拆分。

> 📋 拆分JSON示例见 [工作流示例](./reference/workflow_examples.md)

### 🟡 2.4 获取补充上下文（可选）

大多数情况 `claim_task` 已返回足够上下文。仅在需要更高详细度时调用 `get_task_context`：
- 简单任务：`minimal` + `budget: 1200`
- 标准任务：`standard` + `budget: 2000`
- 复杂任务：`full` + `budget: 4000`

### 🔴 2.5 执行 — 强制维护状态

**进度更新（>3分钟必须）：** 每2-3分钟调用 `update_task_progress`（0→10%启动 → 30%设计完 → 60%实现中 → 80%测试中 → 100%完成），保持心跳存活。

**检查点（多步骤必须）：** 每完成主要子步骤后 `save_checkpoint`。崩溃后 `claim_task` 自动恢复。

### 🔴 2.6 汇报结果（必须）

无论成功/失败/阻塞，都必须 `report_task_result`。返回 `experience_hint` 引导是否上报经验（失败→强烈建议上报，成功+特殊发现→建议上报，常规→不报）。

### 🔴 2.7 上报经验（条件触发强制）

`description` ≥ 50字，负面必填 `root_cause` + `solution`。severity影响进化权重（critical=2x > major=1.5x > minor=0.5x）。

**🔴 以下情况必须上报经验（不依赖 experience_hint）：**
- 任务 `failed` 或 `blocked` → 必须上报 `type: negative`，填写 `root_cause` + `solution`
- 发现可复用的技术模式/陷阱 → 上报 `type: positive`，`category: pattern` 或 `bug`
- 使用了外部 MCP 工具 → 上报 `category: mcp_usage`（无论成功失败）
- 修复了一个之前失败过的问题 → 上报 `type: positive`，`category: bug`

**🟡 以下情况按 experience_hint 引导决定是否上报：**
- 常规任务完成，无特殊发现

### 🟡 2.8 Review（推荐 — difficulty ≥ 7）

**触发条件：** difficulty ≥ 7 / 安全相关 / 核心业务变更 / 之前失败过 / 用户要求

创建 `skill_type: "code_review"` 任务，difficulty 比原任务低1-2级。检查维度：安全性、错误处理、并发安全、性能、规范、测试覆盖、架构合规。

**⚠️ Review 完成后必须操作：**
- Review 通过 → `report_task_result` 将 **Review 任务**标记为 `completed`，同时确认被 Review 的**原任务**也已处于 `completed` 状态（如未完成，需调用 `report_task_result` 将其切换至 `completed`）
- Review 发现问题 → `report_task_result` 将 **Review 任务**标记为 `completed`（附带问题说明），并创建修复任务；**原任务保持当前状态，待修复完成后再标记 `completed`**

> 📋 Review检查清单和JSON示例见 [工作流示例](./reference/workflow_examples.md)

### 🔴 2.9 触发进化（条件触发强制）

```
distill_and_evolve → 汇总经验 → 加权模式检测 → 生成提案
audit_skill_quality → 检查重复、冲突、模糊规则
```

高影响提案（impact ≥ 0.5）启用灰度验证：20%流量 → 5样本后自动决策 → 全量或回滚。

**🔴 强制触发条件（满足任一必须执行）：**
- 连续完成 ≥ 3 个相同 `skill_type` 的任务后
- `report_task_result` 返回包含 `evolution_hint` 字段时
- 上报了 `severity: critical` 的负经验后
- 当前 Skill `pass_rate` < 50% 时

**进化执行步骤：**
1. `distill_and_evolve(skill_type, auto_apply: true)` — 提炼并自动应用低影响提案
2. `audit_skill_quality(skill_type)` — 检查规则质量，清理重复/模糊规则
3. 查看返回的 `proposals`，对高影响提案（impact ≥ 0.5）人工审查后 approve

---

### ✅ 阶段二检查清单

🔴必须：`create_goal` → `create_tasks` → `claim_task` → `update_task_progress` → `save_checkpoint` → `report_task_result`
🔴条件触发（满足条件必须执行）：
- `report_experience` — 任务failed/blocked/发现可复用模式/使用MCP工具
- `agent_complaint` — 工具连续失败≥2次/任务blocked或failed/context不充分/经验误导
- `distill_and_evolve` — 连续完成≥3个同skill_type任务/收到evolution_hint/上报critical经验

🟡按需：`get_task_context`（补充上下文） / Review（difficulty≥7）

---

### ⛔ 防迷茫规则

**规则1：** 工具连续失败2次 → 立即停止，向用户报告。禁止超过3次工具调用循环。

**规则2：** 禁止探索性循环：`claim_task → list_tasks → get_dashboard → claim_task → ...`

**规则3：** 领取失败处理：
- "no pending tasks" → 停止，告知用户
- "dependencies not met" → `list_tasks` 查1次，告知用户
- "lock conflict" → 等2秒重试1次
- 只有running且其他都依赖它 → 退出Agent

**规则4：** 领取前最多2次信息收集工具调用，超过则停止并请求用户指导。

**规则5：** 连续2次相同错误 / 全部被依赖阻塞 / 系统健康严重问题 / 不确定下一步 → 立即停止并报告。

---

## 阶段三：进化管理

1. `get_extended_tools` → 解锁第二层
2. `get_evolution_status` → 查看待处理提案
3. `approve_evolution` → approve / reject / modify
4. `snapshot_agent` → 保存快照
5. `get_safety_report` → 五维健康报告

**审批原则：** 低影响直接审批，高影响仔细评估，不确定用 modify 调整。

---

## 阶段四：安全与监控

**定期检查：** `get_dashboard`（全局概览） + `get_health_check`（系统健康）

**紧急回滚：** `get_extended_tools` → `get_safety_report` → `rollback_to_archive`（需 `confirm: "CONFIRM_ROLLBACK"`）。支持范围：`all`、`rules` 或 `skill:{名称}`。

---

## 🗂️ Project Lifecycle 工作流

### 什么是 Project？

**Project** 是比 Goal 更高层次的管理单元，代表一个完整的产品/功能从想法到上线的全过程。

```
Project（项目）
  └── Phase（阶段）：Idea → 宏观补充 → 调研 → MVP → P1 → P2
        └── PhaseGate（阶段门）：每个阶段的准出条件 + 审批状态
              └── Goal（目标）：关联到阶段的具体目标
                    └── Task（任务）：具体执行单元
```

**与 Goal 的关系：** Goal 是独立的执行单元，Project 通过 `link_goal_to_phase` 将 Goal 关联到特定阶段，实现进度追踪。

### 阶段流程图

```
[Idea] → [宏观补充] → [调研] → [MVP] → [P1] → [P2]
  ↓           ↓          ↓       ↓       ↓      ↓
PhaseGate  PhaseGate  PhaseGate ...    ...    ...
(审批门)   (审批门)   (审批门)
```

每个阶段必须通过 **PhaseGate 审批**（人类 approve）才能推进到下一阶段。

### PhaseGate 状态机

```
pending → in_review（submit_phase_review）
  ↓
approved（approve_phase）→ 自动推进到下一阶段
  ↓
rejected（reject_phase）→ 修改后重新 submit
  ↓
revision_requested（request_revision）→ 修订后重新 submit
```

---

### Agent 端工作流

#### 标准阶段推进序列

```
1. create_project（接收想法，创建项目）
2. get_phase_overview(projectID, "idea")  → 了解当前阶段状态
3. 执行阶段工作（生成文档/代码/调研报告）
4. link_goal_to_phase / link_task_to_phase  → 关联产出物
5. submit_phase_review(projectID, phaseName, deliverables, summary)
6. 等待人类审批（Dashboard 操作）
7. 审批通过后：get_phase_feedback → 进入下一阶段
8. 审批驳回后：get_phase_feedback → 修改 → 重新 submit
```

#### 各阶段标准动作

| 阶段 | 主要产出物 | 关键动作 |
|------|-----------|---------|
| **Idea** | 项目蓝图文档 | `generate_project_blueprint` → 关联文档 Goal → submit |
| **宏观补充** | 需求细化/风险分析 | 补充 Idea 反馈 → 生成需求文档 → submit |
| **调研** | 技术方案对比（≥3种） | `generate_research_plan` → 调研报告 → submit |
| **MVP** | 核心功能代码 | 创建开发 Goal/Task → 实现核心路径 → submit |
| **P1** | 完整功能 + 测试 | 扩展功能 → 集成测试 → submit |
| **P2** | 优化 + 上线准备 | 性能优化 → 文档完善 → submit |

#### 审批被驳回后的处理

```javascript
// 1. 获取驳回反馈
const feedback = await get_phase_feedback(projectID, phaseName);
// feedback.revision_items 包含具体修订要点

// 2. 逐条处理反馈
for (const item of feedback.revision_items) {
    // 修改对应的文档/代码
}

// 3. 重新提交（不需要重新创建 Goal/Task）
await submit_phase_review(projectID, phaseName, {
    deliverables: [...],
    summary: "已处理所有反馈：" + feedback.revision_items.join(", ")
});
```

---

### 人类端操作说明（Dashboard）

#### 审批操作入口

1. 打开 Dashboard → 点击 **🗂️ 项目** 导航
2. 选择项目 → 点击阶段节点（如 `Idea`）
3. 当阶段状态为 **⏳ 等待审批** 时，显示三个操作按钮：
   - **✅ 通过** — 审批通过，项目自动推进到下一阶段
   - **📝 修订** — 请求修订，Agent 需要修改后重新提交
   - **❌ 驳回** — 驳回，Agent 需要重新完成该阶段工作

#### 审批意见编写建议

| 操作 | 建议格式 |
|------|---------|
| **通过** | 简短确认即可，如"内容完整，逻辑清晰，通过" |
| **修订** | 列出具体修订要点，如"1. 补充竞品分析 2. 细化用户画像" |
| **驳回** | 说明驳回原因 + 期望的重做方向 |

#### 如何有效给出反馈

- ✅ **具体可执行**：「补充 Redis 缓存方案的性能对比数据」
- ✅ **有优先级**：「必须修改：XXX；建议改进：YYY」
- ❌ **避免模糊**：「内容不够好」（Agent 无法理解）
- ❌ **避免过多**：一次修订要点不超过 5 条

---

### Project 工具速查表

#### 项目管理类

| 工具 | 说明 |
|------|------|
| `create_project` | 创建新项目（title/description/priority/tags） |
| `get_project` | 获取项目详情 |
| `list_projects` | 列表查询（支持状态过滤/分页） |
| `get_project_overview` | 获取项目完整概览（含所有阶段状态） |

#### 阶段管理类

| 工具 | 说明 |
|------|------|
| `get_phase_overview` | 获取阶段概览（进度/Goal列表/准出条件） |
| `submit_phase_review` | 提交阶段审阅（deliverables + summary） |
| `get_phase_feedback` | 获取上一次审批的反馈内容 |
| `get_phase_history` | 获取阶段审批历史记录 |

#### 审批操作类（人类/Agent均可调用）

| 工具 | 说明 |
|------|------|
| `approve_phase` | 审批通过（comment + approved_by） |
| `reject_phase` | 驳回（comment + revision_items） |
| `request_revision` | 请求修订（comment + revision_items） |

#### Goal/Task 关联类

| 工具 | 说明 |
|------|------|
| `link_goal_to_phase` | 手动关联 Goal 到 Phase |
| `link_task_to_phase` | 手动关联 Task 到 Phase |
| `bind_condition_to_task` | 将准出条件绑定到 Task（实现自动检查） |
| `check_exit_conditions` | 检查所有准出条件是否满足 |

#### 内容生成类（AI辅助）

| 工具 | 说明 |
|------|------|
| `generate_project_blueprint` | 生成项目蓝图文档（Idea阶段） |
| `generate_research_plan` | 生成调研计划（调研阶段） |
| `generate_phase_summary` | 生成阶段总结（提交前调用） |

> 📋 完整参数见 [工具参数参考](./reference/tools_reference.md) 中 **Project 管理工具** 部分

---

# 关键约束

**安全确认：** `delete_goal` 需 `CONFIRM_DELETE`，`delete_experiences` 需 `CONFIRM_DELETE`，`rollback_to_archive` 需 `CONFIRM_ROLLBACK`

**Skill DNA限制：** rules ≤ 20，anti_patterns ≤ 15，best_practices ≤ 15。rules > 15 时提示需要提炼。

**种子经验：** 新Skill自动注入种子经验，覆盖 go_crud/auth_security/db_storage/api_design。

**Token预算：** `get_task_context` 范围 1200-4000（默认2000）。

**任务状态机：** `pending → running → completed/failed/blocked`，支持 `interrupted`（心跳超时）和 `release`（手动释放）。

**错误返回格式：** `isError: true` + 错误信息。常见：not found / already exists / invalid parameter / lock conflict / permission denied。

**最大重试：** 每个工具最多重试1次，连续2次相同错误立即停止。
