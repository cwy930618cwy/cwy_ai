# AgentFlow 工作流示例

## 概述

本文档提供常见 AgentFlow 场景的完整工作流示例。每个示例展示了精确的工具调用序列和参数。

---

## 示例1：完整开发任务（标准流程）

从创建目标到上报经验的标准工作流。**这是每个开发任务都应遵循的流程。**

### 步骤1：创建目标

```json
// create_goal
{
  "title": "实现用户认证模块",
  "description": "开发完整的JWT认证系统，包含登录/注册/Token刷新/权限校验",
  "priority": 8,
  "phases": ["认证接口", "权限中间件", "集成测试"],
  "tags": ["auth", "security", "api"]
}
// → 返回 goal_id: "goal_xxxx"
```

### 步骤2：拆解为任务

```json
// create_tasks
{
  "goal_id": "goal_xxxx",
  "tasks": [
    {
      "title": "实现登录注册接口",
      "description": "POST /api/auth/login 和 POST /api/auth/register",
      "skill_type": "api_design",
      "difficulty": 2,
      "phase": "认证接口",
      "test_design": {
        "unit_tests": ["测试密码哈希", "测试Token生成"],
        "acceptance_criteria": ["登录成功返回JWT", "密码错误返回401"]
      }
    },
    {
      "title": "实现权限中间件",
      "description": "JWT验证中间件 + RBAC权限检查",
      "skill_type": "auth_security",
      "difficulty": 4,
      "phase": "权限中间件",
      "dependencies": ["task_0001"]
    },
    {
      "title": "编写集成测试",
      "description": "端到端测试完整认证流程",
      "skill_type": "testing",
      "difficulty": 2,
      "phase": "集成测试",
      "dependencies": ["task_0001", "task_0002"]
    }
  ]
}
// → 返回 task_ids: ["task_0001", "task_0002", "task_0003"]
```

### 步骤3：领取任务（上下文自动注入）

```json
// claim_task — 上下文自动编译并返回！
{
  "agent_id": "agent_001",
  "task_id": "task_0001"
}
// → 返回：
// {
//   "result": { ...任务详情... },
//   "compiled_context": "\n=== 全局规则 ===\n1. 所有API必须返回JSON\n...\n=== Skill DNA: api_design ===\n规则: ...\n反模式: ...\n最佳实践: ...\n=== 相关经验 ===\n...",
//   "context_tokens": 1850,
//   "heartbeat_hint": { ... }
// }
// ✅ 认真阅读 compiled_context 后再开始编码！
// ✅ 无需额外调用 get_task_context！
```

### 步骤4：汇报结果

```json
// report_task_result
{
  "task_id": "task_0001",
  "agent_id": "agent_001",
  "status": "completed",
  "summary": "实现了登录注册API。登录接口使用bcrypt验证密码后签发JWT(HS256)，注册接口含邮箱格式校验和密码强度检查。",
  "key_decisions": [
    "选择HS256而非RS256简化部署",
    "Token过期时间设置为24h"
  ],
  "tokens_used": 2500,
  "self_reflection": "JWT密钥管理需要后续优化为配置中心获取"
}
```

### 步骤5：上报经验（根据 experience_hint 引导）

```json
// report_task_result 返回的 experience_hint：
// "✅ 任务完成。如果在执行过程中发现了以下情况，建议调用 report_experience 上报：..."
// 本例中发现了有用的模式，因此上报：

// report_experience
{
  "task_id": "task_0001",
  "type": "positive",
  "skill_type": "api_design",
  "category": "pattern",
  "description": "在认证API设计中，将Token签发逻辑封装为独立的TokenService，使得登录和Token刷新可以复用同一套签发逻辑，减少了约40%的重复代码。",
  "confidence": 0.85
}

// ℹ️ 如果任务是常规操作没有特殊发现，
// experience_hint 会提示"无需上报"，此时跳过这一步即可。
```

---

## 示例2：失败任务与负面经验

当任务失败时，清晰汇报失败情况，并**务必在负面经验中包含 root_cause 和 solution**。

### 汇报失败

```json
// report_task_result
{
  "task_id": "task_0002",
  "agent_id": "agent_001",
  "status": "failed",
  "summary": "权限中间件实现失败，JWT解析在并发场景下出现race condition。",
  "test_results": {
    "passed": ["单用户登录验证"],
    "failed": ["并发Token验证", "过期Token处理"],
    "coverage": 45.2
  },
  "self_reflection": "未考虑到middleware中共享状态的并发安全问题"
}
// → 返回 experience_hint：
// "⚠️ 任务失败！请调用 report_experience 上报负经验(type=negative)，务必包含：
//  - root_cause: 失败的根本原因
//  - solution: 建议的解决方案..."
```

### 上报负面经验（根据 experience_hint 引导）

```json
// report_experience — 负面类型必须包含 root_cause 和 solution
{
  "task_id": "task_0002",
  "type": "negative",
  "skill_type": "auth_security",
  "category": "bug",
  "description": "JWT中间件中使用了共享的claims变量来解析Token，在并发请求下多个goroutine同时写入同一个claims对象导致race condition。",
  "root_cause": "中间件handler中声明claims变量在handler函数外层，被多个请求共享",
  "solution": "将claims变量声明移到handler函数内部，确保每个请求独立分配，或使用sync.Pool复用",
  "severity": "critical",
  "confidence": 0.95
}
```

---

## 示例3：经验模式完整流程（搜索→修复→反馈→关闭）

当遇到问题需要查找历史经验并进行修复追踪时的完整流程。

### 步骤1：搜索历史经验

```json
// query_fix_experience — 首次调用，自动创建 Fix Session
{
  "problem": "Redis连接池在高并发下频繁出现timeout错误，连接数超过maxActive限制",
  "error_type": "runtime",
  "error_msg": "redis: connection pool timeout",
  "task_id": "task_0005"
}
// → 返回：
// {
//   "session_id": "fix_session_xxxx",
//   "related_experiences": [
//     {
//       "experience_id": "exp_001",
//       "description": "Redis连接池配置不当导致超时...",
//       "solution": "调整maxActive和maxIdle参数...",
//       "confidence": 0.82,
//       "feedback_summary": { "helpful": 3, "negative": 0 }
//     }
//   ],
//   "suggestions": ["检查连接池配置", "确认是否有连接泄漏"]
// }
```

### 步骤2：尝试修复并记录

```json
// report_fix_attempt — 记录第一次修复尝试
{
  "session_id": "fix_session_xxxx",
  "approach": "按照经验exp_001调整Redis连接池参数，maxActive从10调整为50，maxIdle从5调整为20",
  "reasoning": "历史经验显示连接池参数过小会导致高并发下timeout",
  "result": "partial",
  "result_detail": "timeout错误频率降低但未完全消失，仍有5%的请求超时",
  "modified_files": ["config/redis.yaml"],
  "confidence": 0.6
}
```

### 步骤3：对经验进行反馈

```json
// feedback_experience — 经验部分有效，标记为部分匹配
{
  "experience_id": "exp_001",
  "feedback_type": "negative",
  "negative_tags": ["partial_match"],
  "reason": "调整连接池参数后超时减少但未完全解决，根因可能不仅是参数配置",
  "session_id": "fix_session_xxxx"
}
```

### 步骤4：再次搜索，换个角度

```json
// query_fix_experience — 后续调用必须携带 session_id
{
  "session_id": "fix_session_xxxx",
  "problem": "Redis连接池调大后仍有超时，怀疑存在连接泄漏，某些goroutine未正确归还连接"
}
// → 返回新的建议和相关经验
```

### 步骤5：第二次修复尝试

```json
// report_fix_attempt — 记录第二次修复尝试
{
  "session_id": "fix_session_xxxx",
  "approach": "添加defer conn.Close()确保连接归还，并增加连接泄漏监控日志",
  "reasoning": "怀疑部分代码路径中连接未被正确归还导致泄漏",
  "result": "success",
  "result_detail": "修复后24小时监控无超时错误，连接池使用率稳定在30%以下",
  "modified_files": ["internal/cache/redis.go", "internal/middleware/cache.go"],
  "confidence": 0.95,
  "previous_attempt_helped": "attempt_1"
}
```

### 步骤6：标记尝试结果

```json
// update_fix_attempt_label — 标记尝试1为铺垫，尝试2为正确方案
// 第一次：
{
  "session_id": "fix_session_xxxx",
  "attempt_id": "attempt_1",
  "label": "stepping_stone",
  "label_reason": "调整参数缓解了症状，为定位真正根因提供了线索"
}

// 第二次：
{
  "session_id": "fix_session_xxxx",
  "attempt_id": "attempt_2",
  "label": "correct",
  "label_reason": "修复连接泄漏是根本解决方案"
}
```

### 步骤7：关闭修复会话

```json
// close_fix_session — 提炼最终经验
{
  "session_id": "fix_session_xxxx",
  "status": "resolved",
  "resolution": "Redis超时的根因是部分代码路径中连接未正确归还导致泄漏，添加defer conn.Close()后问题解决",
  "root_cause": "内部缓存层和中间件中存在未归还Redis连接的代码路径",
  "key_insight": "遇到连接池超时，除了调整参数外，优先检查是否有连接泄漏"
}
```

---

## 示例4：进化管理（高级）

积累足够经验后，系统会生成进化提案。以下展示如何管理进化。

### 步骤1：激活第二层

```json
// get_extended_tools — 使用任何第二层工具前必须先调用
{}
// → 返回：工具总数和分层统计
```

### 步骤2：查看进化状态

```json
// get_evolution_status
{}
// → 返回：待处理提案、上次进化时间、Archive最高分
```

### 步骤3：审批提案

```json
// approve_evolution
{
  "evo_id": "evo_xxxx",
  "action": "approve"
}
// 对于不确定的提案，使用 "modify"：
// {
//   "evo_id": "evo_xxxx",
//   "action": "modify",
//   "modification": "将规则中的'必须'改为'建议'，降低强制性"
// }
```

### 步骤4：保存快照（推荐）

```json
// snapshot_agent — 进化后务必保存快照，便于回滚
{
  "trigger": "milestone",
  "note": "完成认证模块后的状态快照"
}
```

### 步骤5：验证健康

```json
// get_safety_report
{}
// → 返回：5维健康评分、校准状态
// 确认进化没有导致技能通过率下降
```

---

## 示例5：紧急回滚

当进化后技能通过率显著下降时，使用此流程进行回滚。

### 步骤1：激活第二层

```json
// get_extended_tools
{}
```

### 步骤2：评估情况

```json
// get_safety_report
{}
// → 返回：技能退化警告 + 可用Archive列表
// 识别哪个技能退化了以及应回滚到哪个Archive
```

### 步骤3：执行回滚

```json
// rollback_to_archive — 范围回滚（仅受影响的技能）
{
  "scope": "skill:auth_security",
  "confirm": "CONFIRM_ROLLBACK"
}
// → 仅将 auth_security 技能回滚到最高分Archive

// 全量回滚：
// {
//   "scope": "all",
//   "confirm": "CONFIRM_ROLLBACK"
// }
```

### 步骤4：验证恢复

```json
// get_safety_report
{}
// → 确认通过率已恢复

// get_dashboard
{}
// → 验证整体系统健康
```

---

## 示例6：长时间任务与心跳管理

当任务涉及大量编码、复杂推理或多文件修改，可能超过3分钟时适用。

### 核心概念：心跳超时

看门狗通过隐式心跳监控Agent活动：
- **软超时（25分钟）**：记录警告，任务继续
- **硬超时（30分钟）**：任务标记为 `interrupted`，释放供恢复

每次MCP工具调用都会自动续期心跳。关键是在长时间操作期间**定期调用MCP工具**。

### 步骤1：领取任务（注意 heartbeat_hint 和 compiled_context）

```json
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0005"
}
// → 返回：
// {
//   "result": { ...任务详情... },
//   "compiled_context": "...（自动编译的上下文，含规则、DNA、经验）...",
//   "context_tokens": 2100,
//   "heartbeat_hint": {
//     "soft_timeout_seconds": 1500,
//     "hard_timeout_seconds": 1800,
//     "message": "⚠️ 请定期调用 update_task_progress 或 save_checkpoint（建议每5-10分钟一次）..."
//   }
// }
// ✅ 认真阅读 compiled_context 后开始工作！
```

### 步骤2：开始工作（上下文已加载，无需 get_task_context）

```json
// ✅ claim_task 返回的 compiled_context 已包含：
// - 全局规则、Skill DNA、相关经验、依赖摘要
// ✅ 仅在需要更高详细度时才调用 get_task_context（如 "full" + budget 4000）

// 直接开始工作！定期汇报进度：
// 完成第一个子步骤后（如数据库Schema）
// update_task_progress — 这会续期心跳！
{
  "task_id": "task_0005",
  "agent_id": "agent_001",
  "progress": 25,
  "message": "数据库Schema设计完成，开始实现API层"
}

// 完成重要里程碑后，保存检查点
// save_checkpoint — 既续期心跳又支持崩溃恢复
{
  "task_id": "task_0005",
  "agent_id": "agent_001",
  "completed_items": ["数据库Schema", "模型定义"],
  "pending_items": ["API接口", "中间件", "集成测试"],
  "modified_files": ["internal/model/user.go", "internal/db/schema.go"],
  "notes": "Schema已创建并通过验证，下一步实现CRUD接口"
}

// 继续工作...完成另一个子步骤后再汇报进度
// update_task_progress
{
  "task_id": "task_0005",
  "agent_id": "agent_001",
  "progress": 60,
  "message": "CRUD接口实现完成，开始编写中间件"
}

// 完成另一个主要部分后，再次保存检查点
// save_checkpoint
{
  "task_id": "task_0005",
  "agent_id": "agent_001",
  "completed_items": ["数据库Schema", "模型定义", "CRUD接口", "中间件"],
  "pending_items": ["集成测试"],
  "modified_files": ["internal/model/user.go", "internal/db/schema.go", "internal/handler/user.go", "internal/middleware/auth.go"],
  "notes": "核心功能完成，仅剩集成测试"
}
```

### 步骤3：汇报结果和经验

```json
// report_task_result
{
  "task_id": "task_0005",
  "agent_id": "agent_001",
  "status": "completed",
  "summary": "实现了完整的用户管理模块：Schema+模型+CRUD接口+认证中间件+集成测试，所有测试通过。",
  "tokens_used": 8500,
  "self_reflection": "任务耗时较长，通过定期save_checkpoint确保了进度不丢失"
}

// report_experience
{
  "task_id": "task_0005",
  "type": "positive",
  "skill_type": "go_crud",
  "category": "pattern",
  "description": "在长时间执行的大型开发任务中，每完成一个子模块后立即调用save_checkpoint保存已完成项和待完成项，既维持了心跳避免被Watchdog中断，又确保了意外崩溃时可以从检查点恢复，不需要重复已完成的工作。",
  "confidence": 0.9
}
// ℹ️ 本例上报经验是因为发现了有用的工作模式。
// 如果 experience_hint 提示"无需上报"，则跳过此步骤。
```

---

## 示例7：首次连接 — 系统状态检查（强制步骤）

**⚠️ 这是连接AgentFlow后必须做的第一件事。** 在创建目标、领取任务或做其他事之前，先了解当前系统状态。

### 步骤1：检查系统概览

```json
// get_dashboard — 始终第一步调用
{}
// → 返回：目标数量、任务状态分布、技能统计
```

### 步骤2：根据状态决定下一步

根据仪表盘响应，遵循以下决策树：

**情况A：没有目标**
```
// 用户要求"执行任务"但没有目标
// → 询问用户要达成什么目标，然后 create_goal
// ❌ 不要调用 claim_task — 没有任务可领取！
```

**情况B：有目标但没有待处理任务**
```
// 检查是否需要创建任务
// list_tasks → { goal_id: "goal_xxx" }
// 如果所有任务已完成 → 通知用户目标已达成
// 如果没有创建过任务 → create_tasks
```

**情况C：有中断/失败/阻塞的任务 → 优先领取**
```json
// 优先级：interrupted > failed > blocked > pending
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "具体的中断/失败/阻塞任务ID"
}
// → 成功！compiled_context 已包含在内，直接开始工作！
```

**情况D：有待处理任务 → 正常领取**
```json
// claim_task
{
  "agent_id": "agent_001"
}
// → 成功！compiled_context 已包含，开始工作！
```

**情况E：只有进行中（running）的任务，其他任务都依赖于它**
```
// ⛔ 绝对不要领取 running 状态的任务！
// → 立即停止
// → 告知用户："所有待处理任务都依赖于正在进行的任务 [任务名]，需等待其完成"
// → 退出Agent或建议用户等待
```

**情况F：claim_task 返回错误**
```
// ❌ 错误做法：立即重试或循环调用 get_health_check
// ✅ 正确做法：阅读错误信息并相应处理

// 错误："no pending tasks" → 检查 list_tasks，通知用户
// 错误："Redis script error" → 调用 get_health_check 一次，向用户报告
// 错误："lock conflict" → 等待2秒，仅重试一次
// 错误：未知 → 停止并向用户报告确切错误

// ⛔ 最多重试1次。如果失败两次，立即停止并通知用户。
```

### 反模式：禁止这样做

```
// ❌ 这是导致Bug的循环。绝对不要这样做：
claim_task → 错误 → get_health_check → get_dashboard → claim_task → 错误 → ...

// ❌ 不要在不检查状态的情况下假设存在任务：
// 用户说"执行" → 立即调用 claim_task → 错误

// ✅ 正确流程：
// 用户说"执行" → get_dashboard → 理解状态 → 决定行动
```

---

## 示例8：带依赖和前提条件的任务

当创建有执行顺序要求的任务时，使用依赖和前提条件。

### 步骤1：创建带依赖的任务

```json
// create_tasks
{
  "goal_id": "goal_xxxx",
  "tasks": [
    {
      "title": "设计数据库Schema",
      "description": "设计用户表、订单表和关联关系",
      "skill_type": "db_storage",
      "phase": "数据层"
    },
    {
      "title": "实现CRUD接口",
      "description": "基于Schema实现用户和订单的增删改查API",
      "skill_type": "go_crud",
      "phase": "接口层",
      "dependencies": ["设计数据库Schema"],
      "prerequisites": ["数据库Schema已创建并通过验证", "Redis连接已配置"]
    },
    {
      "title": "编写集成测试",
      "description": "端到端测试完整业务流程",
      "skill_type": "testing",
      "phase": "测试",
      "dependencies": ["实现CRUD接口"]
    }
  ]
}
// → 系统解析 "设计数据库Schema" → task_0001, "实现CRUD接口" → task_0002
// → 系统在创建前执行循环依赖检测（DFS）
// → task_0002 创建时状态为 "blocked"（依赖 task_0001）
// → task_0003 创建时状态为 "blocked"（依赖 task_0002）
```

### 步骤2：处理被阻塞的任务

```json
// claim_task — 尝试领取被阻塞的任务
{
  "agent_id": "agent_001",
  "task_id": "task_0002"
}
// → 错误："dependencies not met: 依赖任务 [设计数据库Schema](task_0001) 当前状态为 pending，需等待其完成"
// → ✅ 错误信息包含具体的任务名称、ID和当前状态！

// 正确做法：先领取未被阻塞的任务
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0001"
}
// → 成功！task_0001 正在运行，compiled_context 已包含
```

### 步骤3：跨目标依赖

任务也可以使用 task_id 引用其他目标的任务：

```json
// create_tasks — 在另一个目标中
{
  "goal_id": "goal_yyyy",
  "tasks": [
    {
      "title": "构建管理后台",
      "description": "依赖用户模块的API",
      "skill_type": "api_design",
      "dependencies": ["task_0002"]
    }
  ]
}
// → 跨目标依赖：goal_yyyy 中的任务依赖 goal_xxxx 中的任务
```

---

## 示例9：灰度进化验证

积累经验后，高影响进化提案会经过灰度验证而非立即全局部署。

### 步骤1：触发带加权评分的提炼

```json
// distill_and_evolve
{
  "skill_type": "go_crud",
  "auto_apply": true,
  "include_stale": true
}
// → 返回：
// {
//   "proposals_generated": 3,
//   "proposals_applied": 2,       ← 低影响提案已自动应用
//   "proposals_pending": 1,        ← 高影响提案 → 灰度验证
//   "proposals": [
//     { "impact": 0.3, "status": "applied" },        ← 低影响 → 直接应用
//     { "impact": 0.2, "status": "applied" },        ← 低影响 → 直接应用
//     { "impact": 0.7, "status": "canary",           ← 高影响 → 灰度验证！
//       "canary_info": {
//         "candidate_version": 6,
//         "stable_version": 5,
//         "ratio": 0.2,
//         "min_samples": 5
//       }
//     }
//   ]
// }
```

### 步骤2：灰度自动决策（对Agent透明）

灰度机制透明运作：
- 使用 `go_crud` 技能的20%任务将接收candidate版本（v6）
- 80%继续使用stable版本（v5）
- 5+个任务完成后：
  - 成功率 ≥ 95% → candidate成为新的stable（自动晋升）
  - 成功率 < 90% → candidate被回滚（自动回滚）
  - 90%-95%之间 → 继续观察

### 步骤3：通过仪表盘监控

```json
// get_evolution_status
{}
// → 显示：go_crud 灰度进行中，3/5个样本已收集，当前成功率100%
```

---

## 示例11：复杂任务拆分为孙任务

当领取的任务过于复杂时，Agent 可以自行拆分为多个更小的孙任务。

### 步骤1：领取任务后发现过于复杂

```json
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0010"
}
// → 返回：task_0010 "实现完整的订单管理模块" (difficulty: 5)
// → 阅读 compiled_context 后发现涉及：
//   - 3个数据库表设计
//   - 5个API接口
//   - 状态机逻辑
//   - 支付集成
// → 判断：任务过于复杂，需要拆分
```

### 步骤2：创建孙任务

```json
// create_tasks — 将父任务拆分为3个孙任务
{
  "goal_id": "goal_xxxx",
  "tasks": [
    {
      "title": "[拆分自task_0010] 订单数据库Schema与模型",
      "description": "设计订单表(orders)、订单项表(order_items)、支付记录表(payments)的Schema和ORM模型。拆分自 task_0010。",
      "skill_type": "db_storage",
      "difficulty": 2
    },
    {
      "title": "[拆分自task_0010] 订单CRUD接口",
      "description": "实现创建订单、查询订单列表、订单详情、取消订单API。拆分自 task_0010。",
      "skill_type": "api_design",
      "difficulty": 3,
      "dependencies": ["[拆分自task_0010] 订单数据库Schema与模型"]
    },
    {
      "title": "[拆分自task_0010] 订单状态机与支付集成",
      "description": "实现订单状态流转（待支付→已支付→已发货→已完成→已取消）和支付回调处理。拆分自 task_0010。",
      "skill_type": "go_crud",
      "difficulty": 4,
      "dependencies": ["[拆分自task_0010] 订单CRUD接口"]
    }
  ]
}
// → 返回 task_ids: ["task_0010a", "task_0010b", "task_0010c"]
```

### 步骤3：更新父任务描述

```json
// update_task — 标记父任务为聚合任务
{
  "task_id": "task_0010",
  "fields": {
    "description": "[聚合任务] 实现完整的订单管理模块。已拆分为3个孙任务：task_0010a(Schema) → task_0010b(CRUD) → task_0010c(状态机+支付)。所有孙任务完成后此任务自动完成。"
  }
}
```

### 步骤4：按顺序执行孙任务

```json
// 先释放父任务（因为要按孙任务顺序执行）
// release_task
{
  "task_id": "task_0010",
  "agent_id": "agent_001",
  "reason": "已拆分为3个孙任务，按顺序执行孙任务"
}

// 领取第一个孙任务
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0010a"
}
// → 执行 → 汇报 → 领取下一个 → ... 直到所有孙任务完成
```

### 步骤5：所有孙任务完成后，汇报父任务

```json
// 重新领取父任务
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0010"
}

// 汇报父任务完成
// report_task_result
{
  "task_id": "task_0010",
  "agent_id": "agent_001",
  "status": "completed",
  "summary": "通过拆分为3个孙任务完成：Schema设计(task_0010a) → CRUD接口(task_0010b) → 状态机+支付(task_0010c)。所有孙任务已完成。"
}
```

---

## 示例12：Agent Review 任务

当重要任务完成后，创建 Review 任务进行代码审查。

### 步骤1：完成主任务后创建 Review 任务

```json
// 前置：task_0011 "实现用户认证中间件" (difficulty: 4) 已完成

// create_tasks — 创建 review 任务
{
  "goal_id": "goal_xxxx",
  "tasks": [
    {
      "title": "Review: 用户认证中间件实现",
      "description": "对 task_0011 的产出物进行 Code Review。\n检查重点：\n1. JWT Token验证是否完整（签名/过期/格式）\n2. 并发安全（claims解析是否线程安全）\n3. 错误处理（401/403区分是否正确）\n4. 性能（Token缓存策略是否合理）\n5. 安全（密钥管理是否安全）",
      "skill_type": "code_review",
      "difficulty": 2,
      "dependencies": ["task_0011"]
    }
  ]
}
// → 返回 task_ids: ["task_0012"]
```

### 步骤2：领取并执行 Review

```json
// claim_task
{
  "agent_id": "agent_002",
  "task_id": "task_0012"
}
// → 返回 compiled_context（包含 code_review 技能的 DNA + task_0011 的产出摘要）

// 查看被 review 任务的详情
// get_task_detail
{ "task_id": "task_0011" }
// → 返回：code_output、test_results 等

// 查看具体文件
// get_artifact
{ "file_path": "internal/middleware/auth.go", "extract_mode": "full" }

// 对照 Skill DNA 检查
// get_skill
{ "name": "auth_security" }
```

### 步骤3：汇报 Review 结果

**场景A：Review 通过**
```json
// report_task_result
{
  "task_id": "task_0012",
  "agent_id": "agent_002",
  "status": "completed",
  "summary": "Review通过。认证中间件实现质量良好：JWT验证完整、并发安全（claims在handler内声明）、错误码区分正确。建议：可考虑添加Token刷新的滑动窗口机制。",
  "key_decisions": ["确认并发安全性", "建议增加Token刷新优化"]
}
```

**场景B：Review 发现问题，需要返工**
```json
// report_task_result
{
  "task_id": "task_0012",
  "agent_id": "agent_002",
  "status": "completed",
  "summary": "Review发现2个问题需修复：1) auth中间件未处理Token过期的graceful降级 2) 密钥硬编码在常量中，应从配置中心获取。建议创建修复任务。",
  "key_decisions": ["发现密钥硬编码安全风险", "发现过期Token处理缺陷"]
}

// 上报经验（发现了通用性安全问题）
// report_experience
{
  "task_id": "task_0012",
  "type": "negative",
  "skill_type": "auth_security",
  "category": "security",
  "description": "在Code Review中发现JWT密钥被硬编码在代码常量中（const jwtSecret = 'xxx'），这是严重的安全隐患。密钥应从环境变量或配置中心获取，且不应出现在版本控制中。",
  "root_cause": "开发时图方便将密钥写在常量中，未考虑安全最佳实践",
  "solution": "使用 os.Getenv('JWT_SECRET') 或配置中心SDK获取密钥，并在.gitignore中排除包含密钥的配置文件",
  "severity": "critical",
  "confidence": 0.95
}

// 创建修复任务
// create_tasks
{
  "goal_id": "goal_xxxx",
  "tasks": [
    {
      "title": "修复: 认证中间件Review问题",
      "description": "修复 task_0012 Review 中发现的2个问题：1) 添加Token过期graceful降级逻辑 2) 将JWT密钥从硬编码改为配置中心获取",
      "skill_type": "auth_security",
      "difficulty": 3,
      "dependencies": ["task_0012"]
    }
  ]
}
```

---

## 示例13：按难度评分领取任务

展示如何根据任务难度评分选择合适的任务领取。

### 步骤1：查看任务列表及难度

```json
// get_dashboard → 发现有5个待处理任务
// list_tasks
{ "status": "pending" }
// → 返回：
// task_0020: "修改错误提示文案" (difficulty: 1, skill: api_design)
// task_0021: "实现用户列表分页" (difficulty: 2, skill: go_crud)
// task_0022: "重构缓存层架构" (difficulty: 5, skill: db_storage)
// task_0023: "添加操作日志中间件" (difficulty: 3, skill: go_crud)
// task_0024: "实现分布式锁" (difficulty: 4, skill: db_storage)
```

### 步骤2：按难度匹配选择

```json
// 策略：先从中等难度开始，积累上下文后再挑战高难度

// 第一个任务：选择 difficulty 2-3 的任务
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0021"
}
// → 领取 "实现用户列表分页" (difficulty: 2)
// → 完成后积累了 go_crud 经验

// 第二个任务：有了经验，可以挑战 difficulty 3
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0023"
}
// → 领取 "添加操作日志中间件" (difficulty: 3)

// 第三个任务：经验充足，挑战高难度
// claim_task
{
  "agent_id": "agent_001",
  "task_id": "task_0024"
}
// → 领取 "实现分布式锁" (difficulty: 4)

// 第四个任务：最高难度，确认自己有足够能力
// 如果 task_0022 (difficulty: 5) 太复杂 → 考虑拆分后再领取
```

### 使用智能派发（带难度过滤）

```json
// 让系统根据难度范围智能派发
// claim_task
{
  "agent_id": "agent_001",
  "max_difficulty": 3
}
// → 系统在 difficulty ≤ 3 的待处理任务中智能选择
```

---

## 示例14：MCP 工具使用经验记录

在经验模式下使用外部 MCP 工具（Cocos MCP、Unity MCP、数据库 MCP 等）时，**必须**记录使用经验。

### 场景A：成功使用 Cocos MCP — 记录正面经验

```json
// 使用 Cocos MCP 创建UI节点
// 1. 先获取场景树
// use_mcp_tool: cocos_mcp → get_scene_tree
// → 返回场景节点树，找到目标父节点路径: "/Canvas/UIRoot/Panel"

// 2. 创建节点
// use_mcp_tool: cocos_mcp → create_node
// { "name": "BtnStart", "parent_path": "/Canvas/UIRoot/Panel", "type": "Button" }
// → 返回 { "node_uuid": "abc123", "success": true }

// 3. 设置组件属性
// use_mcp_tool: cocos_mcp → set_component_property
// { "node_uuid": "abc123", "component": "cc.Button", "property": "transition", "value": 2 }
// → 成功

// ✅ 必须记录 MCP 使用经验！
// report_experience
{
  "task_id": "task_xxxx",
  "type": "positive",
  "skill_type": "go_crud",
  "category": "mcp_usage",
  "description": "使用 Cocos MCP 创建UI节点的正确流程：1) 先调用 get_scene_tree 获取完整的场景节点树，定位目标父节点的绝对路径（必须以'/'开头）2) 调用 create_node 时传入 parent_path 参数指定父节点（不传则创建到场景根节点下）3) create_node 返回的 node_uuid 必须缓存，后续所有对该节点的操作（set_component_property/add_component等）都需要此uuid作为标识。注意：node_uuid 在场景重新加载后会失效，需要重新获取。",
  "confidence": 0.9
}
```

### 场景B：使用 Unity MCP 踩坑 — 记录负面经验

```json
// 使用 Unity MCP 编译脚本
// use_mcp_tool: unity_mcp → compile_script
// { "script_path": "Assets/Scripts/Player/PlayerController.cs" }
// → 返回 { "success": true }  // 但实际编译未生效！

// 后续发现脚本引用了未导入的包 DOTween
// 排查后发现：compile_script 对缺失包的情况返回 success 但静默失败

// ✅ 必须记录踩坑经验！
// report_experience
{
  "task_id": "task_xxxx",
  "type": "negative",
  "skill_type": "go_crud",
  "category": "mcp_usage",
  "description": "使用 Unity MCP 的 compile_script 工具时发现严重坑点：当脚本引用了尚未导入的第三方包时，编译会静默失败——工具返回 success: true 但脚本实际未正确编译。这导致后续运行时才发现问题，浪费了大量调试时间。",
  "root_cause": "Unity MCP 的 compile_script 不会自动解析和验证第三方包依赖，缺失依赖时不报错而是静默跳过",
  "solution": "在调用 compile_script 之前，必须先调用 list_packages 检查所有依赖包是否已导入。缺失的包通过 import_package 工具导入后，再执行编译。建议形成固定流程：list_packages → import_package(缺失的) → compile_script",
  "severity": "major",
  "confidence": 0.9
}
```

### 场景C：发现 MCP 工具组合调用模式

```json
// 完成了一系列 Cocos MCP 操作后，发现了高效的组合调用模式

// report_experience
{
  "task_id": "task_xxxx",
  "type": "positive",
  "skill_type": "api_design",
  "category": "mcp_usage",
  "description": "发现 Cocos MCP 批量操作场景节点的最佳实践：1) 使用 get_scene_tree 一次性获取完整节点树（避免多次查询）2) 在内存中规划好所有需要的操作 3) 批量执行 create_node/add_component/set_property 4) 最后调用一次 save_scene 统一保存。关键发现：不要在每次 create_node 后立即 save_scene，这会触发编辑器重新序列化整个场景，批量创建10个节点+每次保存耗时约15秒，而批量创建后统一保存仅需2秒。",
  "confidence": 0.85
}
```

### 场景D：MCP 工具版本差异记录

```json
// 发现 Cocos MCP 在不同 Creator 版本下行为不同

// report_experience
{
  "task_id": "task_xxxx",
  "type": "negative",
  "skill_type": "db_storage",
  "category": "mcp_usage",
  "description": "Cocos MCP 的 load_asset 工具在 Creator 3.7 和 3.8 版本中行为不同：3.7 版本支持直接传入资源路径字符串（如 'textures/bg'），3.8+ 版本必须传入带 bundle 名的完整路径（如 'resources/textures/bg'）且必须指定 asset_type 参数。如果在 3.8+ 中使用旧格式调用，会返回 'asset not found' 但不会提示是路径格式问题。",
  "root_cause": "Cocos Creator 3.8 重构了 Asset Bundle 系统，资源加载API的路径解析逻辑发生了变化",
  "solution": "使用 load_asset 前先通过 get_engine_version 确认 Creator 版本。3.8+ 版本统一使用 'bundle名/资源路径' 格式，并始终指定 asset_type 参数",
  "severity": "major",
  "confidence": 0.8
}
```

---

## 示例16：经验迭代清理工作流

通过 `list_experiences` + `delete_experiences` 分批审查和清理经验库，维护经验质量。

### 步骤1：分批获取经验

```json
// list_experiences — 第一页（无过滤）
{
  "type": "negative",
  "batch_size": 10
}
// → 返回：
// {
//   "experiences": [{"id": "1234-0", "description": "...", "skill_type": "go_crud", ...}, ...],
//   "cursor": "1234-0",
//   "has_more": true
// }
```

### 步骤2：按条件过滤查看

```json
// list_experiences — 按 skill_type 过滤
{
  "type": "negative",
  "skill_type": "go_crud",
  "batch_size": 20
}
// → 返回 go_crud 的所有负面经验

// list_experiences — 按关键词搜索
{
  "type": "positive",
  "keyword": "连接池",
  "batch_size": 20
}
// → 返回描述中包含"连接池"的正面经验
```

### 步骤3：用游标继续获取下一页

```json
// list_experiences — 传入上一页返回的 cursor
{
  "type": "negative",
  "cursor": "1234-0",
  "batch_size": 10
}
// → 返回下一批经验，has_more 为 false 时到末尾
```

### 步骤4：审查后批量删除无效经验

```json
// delete_experiences — 必须提供 CONFIRM_DELETE 确认
{
  "type": "negative",
  "ids": ["1234-0", "1235-0", "1240-0"],
  "confirm": "CONFIRM_DELETE"
}
// → 返回：
// {
//   "deleted": 3,
//   "failed": [],
//   "message": "成功删除 3 条经验"
// }
```

### 步骤5：删除后触发进化提炼

```json
// distill_and_evolve — 清理后重新提炼
{
  "skill_type": "go_crud",
  "auto_apply": true,
  "include_stale": true
}
// → 基于剩余高质量经验重新进化
```

---

## 示例17：Agent 吐槽与改进建议

当对工具、经验、Skill规则等感到不满时，通过 `agent_complaint` 记录吐槽。高频吐槽自动触发进化。

### 场景A：经验质量问题

```json
// agent_complaint
{
  "type": "experience",
  "severity": "frustrating",
  "complaint": "多次查询到的 go_crud 经验过于笼统，缺乏具体代码示例和可操作步骤，导致无法直接应用。",
  "suggestion": "经验应强制要求包含 code_example 字段，特别是负面经验的 solution 应含示例代码",
  "related_skill": "go_crud",
  "agent_id": "agent_001"
}
// → 返回：
// {
//   "complaint_id": "cpl_xxx",
//   "similar_complaints": 2,
//   "auto_evolution_hint": "⇒ 同维度吐槽已累计3次，建议触发 distill_and_evolve"
// }
```

### 场景B：工具使用问题

```json
// agent_complaint
{
  "type": "tool",
  "severity": "blocking",
  "complaint": "claim_task 智能派发反复分配同一个已失败的任务，尽管已尝试多次并确认是环境问题而非代码问题。",
  "suggestion": "智能派发应考虑任务的失败次数，连续失败3次以上的任务应降低派发优先级",
  "related_tool": "claim_task",
  "related_task_id": "task_0040",
  "agent_id": "agent_001"
}
```

### 场景C：查看吐槽统计

```json
// get_complaint_stats
{}
// → 返回：按类型/严重程度/工具/Skill聚合统计
// 热点："experience" 类型 frustrating 级别吐槽 5次 → 建议触发进化
```

---

## 示例10：经验反馈与负面词标记

当使用历史经验发现质量问题时，进行反馈标记。

### 场景A：经验有帮助

```json
// feedback_experience — 正面反馈
{
  "experience_id": "exp_001",
  "feedback_type": "helpful",
  "negative_tags": [],
  "reason": "按照经验中的方案修复了Redis超时问题，非常有效"
}
```

### 场景B：经验误导性

```json
// feedback_experience — 严重误导
{
  "experience_id": "exp_002",
  "feedback_type": "misleading",
  "negative_tags": ["misleading", "wrong_root_cause"],
  "reason": "经验说根因是连接池配置，但实际根因是连接泄漏。按照经验修改配置后问题反而更严重",
  "mismatch_detail": "经验建议增大maxActive到100，但这只是掩盖了连接泄漏的问题",
  "session_id": "fix_session_xxxx"
}
// ⚠️ misleading 类型累计≥3次将触发经验拉黑
```

### 场景C：经验已过时

```json
// feedback_experience — 信息过时
{
  "experience_id": "exp_003",
  "feedback_type": "outdated",
  "negative_tags": ["outdated", "context_mismatch"],
  "reason": "经验中使用的是 redis v6 的API，当前项目已升级到 redis v7，接口已变更"
}
```

### 场景D：经验太笼统

```json
// feedback_experience — 缺乏可操作细节
{
  "experience_id": "exp_004",
  "feedback_type": "negative",
  "negative_tags": ["too_vague", "partial_match"],
  "reason": "经验只说'优化数据库查询'，没有给出具体的优化手段和适用场景"
}
```

---

## 示例15：长上下文防护 — 棘手问题排查进度持久化

当 Agent 遇到棘手问题需要长时间排查，上下文快速膨胀时，通过 Fix Session + Checkpoint 双通道持久化排查进度，确保对话中断后下一个 Agent 可以无缝续接。

### 场景背景

Agent 在执行任务 `task_0030` 时遇到一个复杂的运行时崩溃。已经排查了多个方向，阅读了大量代码文件，上下文越来越长。

### 步骤1：感知到问题棘手，立即创建 Fix Session

```json
// query_fix_experience — 首次调用，创建 Fix Session
{
  "problem": "执行 CleanUp 后游戏崩溃，错误信息显示 'Cannot read property children of null'。已检查了 ItemBaseView、BoardView、EffectManager 三个模块，怀疑是节点销毁顺序问题或 Tween 回调在节点已销毁后仍在执行。",
  "error_type": "runtime",
  "error_msg": "TypeError: Cannot read property 'children' of null at Tween.update",
  "task_id": "task_0030"
}
// → 返回 session_id: "fix_session_abc123"
// → 返回历史相关经验（如有）
```

### 步骤2：排查方向A — 记录排查结果

```json
// 排查了 ItemBaseView.CleanUp() 的销毁逻辑

// report_fix_attempt — 立即记录
{
  "session_id": "fix_session_abc123",
  "approach": "检查 ItemBaseView.CleanUp() 中子节点销毁逻辑，查看是否存在遍历中销毁导致数组长度变化的问题",
  "reasoning": "错误堆栈指向 Tween.update 访问 null 的 children，怀疑是节点销毁后 Tween 仍在运行",
  "result": "partial",
  "result_detail": "发现 CleanUp 中直接遍历 children 数组并 destroy，确实存在数组长度变化问题。但修复后崩溃仍然存在，说明还有其他原因。",
  "modified_files": ["assets/Script/modules/Match3/NewCore/ItemBaseView.ts"],
  "confidence": 0.4
}

// update_fix_attempt_label — 标记为铺垫步骤
{
  "session_id": "fix_session_abc123",
  "attempt_id": "attempt_1",
  "label": "stepping_stone",
  "label_reason": "修复了遍历销毁Bug，但崩溃仍存在，说明这只是部分原因"
}
```

### 步骤3：排查方向B — 记录并排除

```json
// 排查了 EffectManager 的特效回收逻辑

// report_fix_attempt — 立即记录
{
  "session_id": "fix_session_abc123",
  "approach": "检查 EffectManager 的特效节点回收逻辑，查看是否有异步特效在棋盘清理后仍在播放",
  "reasoning": "特效节点挂在棋盘节点下，如果棋盘先销毁而特效 Tween 还在运行，就会出现 null 引用",
  "result": "failed",
  "result_detail": "EffectManager 有自己的对象池管理，特效节点是独立管理的，不挂在棋盘节点下。排除此方向。",
  "confidence": 0.2
}

// update_fix_attempt_label — 标记为死路
{
  "session_id": "fix_session_abc123",
  "attempt_id": "attempt_2",
  "label": "dead_end",
  "label_reason": "EffectManager 有独立节点池，与棋盘销毁无关，排除此方向"
}
```

### 步骤4：发现可疑线索 — 标记为有前景

```json
// 排查 BoardView 的 Tween 清理逻辑时发现可疑问题

// report_fix_attempt — 立即记录
{
  "session_id": "fix_session_abc123",
  "approach": "检查 BoardView.destroy() 中 Tween 清理逻辑，发现 _viewTransform 上的 Tween 在 destroy 前没有被停止",
  "reasoning": "如果 _viewTransform 上有正在运行的 Tween，destroy 后 Tween 的 update 回调会访问已销毁节点的 children 属性",
  "result": "partial",
  "result_detail": "【高度可疑】发现 BoardView.destroy 没有调用 Tween.stopAllByTarget(_viewTransform)。需要进一步验证：1)确认 _viewTransform 上确实有活跃 Tween 2)在 destroy 前添加 stopAll 是否能解决崩溃",
  "confidence": 0.7
}

// update_fix_attempt_label — 标记为有前景
{
  "session_id": "fix_session_abc123",
  "attempt_id": "attempt_3",
  "label": "promising",
  "label_reason": "发现 _viewTransform 的 Tween 未被清理，与错误堆栈完全吻合，高度可疑"
}
```

### 步骤5：感知上下文膨胀 — 做阶段性总结

```json
// 感觉对话已经很长了，主动做阶段性总结

// report_fix_attempt — 阶段性总结
{
  "session_id": "fix_session_abc123",
  "approach": "【阶段性总结】棘手崩溃问题排查进度汇总",
  "reasoning": "上下文已较长，主动保存全部排查进度，确保对话中断后下一个Agent可以续接",
  "result": "partial",
  "result_detail": "【已排查并处理】\n1. attempt_1 (stepping_stone): ItemBaseView.CleanUp 遍历销毁Bug已修复，但非根因\n2. attempt_2 (dead_end): EffectManager 特效回收逻辑与此问题无关\n\n【高度可疑 — 建议优先排查】\n3. attempt_3 (promising): BoardView.destroy 未停止 _viewTransform 上的 Tween，与错误堆栈完全吻合\n   - 待验证：在 destroy 前添加 Tween.stopAllByTarget(_viewTransform)\n   - 相关文件：BoardView.ts 的 destroy/onDestroy 方法\n\n【尚未排查】\n4. Container 节点的 Tween 清理（如果 BoardView 方向确认，这也需要一并处理）\n5. 是否存在其他模块持有已销毁节点引用的情况",
  "confidence": 0.6
}

// save_checkpoint — 同时保存任务检查点
{
  "task_id": "task_0030",
  "agent_id": "agent_001",
  "completed_items": [
    "修复了 ItemBaseView.CleanUp 遍历销毁Bug",
    "排除了 EffectManager 方向",
    "发现 BoardView Tween 清理缺失（高度可疑）"
  ],
  "pending_items": [
    "验证 BoardView 添加 Tween.stopAllByTarget 是否修复崩溃",
    "检查 Container 节点的 Tween 清理",
    "检查其他模块是否持有已销毁节点引用"
  ],
  "modified_files": ["assets/Script/modules/Match3/NewCore/ItemBaseView.ts"],
  "notes": "棘手崩溃排查中。Fix Session: fix_session_abc123。高度可疑方向：BoardView.destroy 未停止 _viewTransform 的 Tween。"
}
```

### 步骤6：下一个 Agent 续接（对话中断后）

```json
// 新 Agent 启动后：

// 步骤1：领取任务，自动恢复检查点
// claim_task
{
  "agent_id": "agent_002",
  "task_id": "task_0030"
}
// → 返回：
// checkpoint: {
//   completed_items: ["修复了 ItemBaseView.CleanUp ...", ...],
//   pending_items: ["验证 BoardView ...", ...],
//   notes: "...Fix Session: fix_session_abc123..."
// }
// → 从 notes 中获取 Fix Session ID

// 步骤2：查询 Fix Session，获取完整排查历史
// query_fix_experience
{
  "session_id": "fix_session_abc123",
  "problem": "继续排查 CleanUp 后崩溃问题，上一个Agent已排查3个方向"
}
// → 返回所有历史排查记录（含标记）：
//   attempt_1: stepping_stone（ItemBaseView修复）
//   attempt_2: dead_end（EffectManager排除）
//   attempt_3: promising（BoardView Tween未清理 — 高度可疑！）

// 步骤3：直接从 promising 方向继续排查
// → 验证 BoardView.destroy 添加 Tween.stopAllByTarget
// → 无需重复排查 dead_end 方向
```

### 关键要点

| 原则 | 说明 |
|------|------|
| **尽早启动** | 感觉问题棘手就立即创建 Fix Session，不要等到快溢出 |
| **实时记录** | 排查一步记录一步，不要积攒 |
| **明确标记** | `dead_end`/`promising`/`stepping_stone` 让下一个 Agent 一目了然 |
| **阶段性总结** | 感知上下文长时主动总结，包含：已排查+可疑+建议方向 |
| **双通道持久化** | Fix Session（排查历史）+ Checkpoint（任务进度）双保险 |

---

## 快速参考：必须步骤 vs 可选步骤

| 步骤 | 使用时机 | 是否必须？ |
|------|---------|-----------|
| `get_dashboard` | **每次连接后第一件事** | ✅ **始终必须（最先执行）** |
| `create_goal` | 开始新目标时 | ✅ 是 |
| `create_tasks` | 创建目标后 | ✅ 是 |
| `claim_task` | 开始处理任务前（仅在有可领取任务时，优先interrupted>failed>blocked>pending，禁止领取running，考虑难度匹配） | ✅ 是（自动包含上下文） |
| `get_task_context` | 仅在claim未返回上下文或需要更高详细度时 | 🟡 可选 |
| `update_task_progress` | 任务执行期间（长任务每5-10分钟） | 🟠 推荐（维持心跳） |
| `save_checkpoint` | 完成主要子步骤后 | 🔶 推荐（心跳+崩溃恢复） |
| `report_task_result` | 完成任务后 | ✅ 是（查看 experience_hint） |
| `report_experience` | 汇报结果后，根据 experience_hint 引导 | 🟡 按引导（非必须） |
| Review 任务 | 重要任务完成后（difficulty≥3），创建 code_review 任务 | 🟡 推荐 |
| 经验迭代清理 | 完成一批任务后，用 `list_experiences` + `delete_experiences` 审查清理 | 🟡 推荐 |
| Agent吐槽 | 对工具/经验/规则不满时，用 `agent_complaint` 记录 | 🟡 推荐 |
| 子任务拆分 | 领取后发现任务过于复杂时，拆分为孙任务 | 🟡 按需 |
| `query_fix_experience` | 遇到问题需要查找历史经验时 | 🟡 按需 |
| MCP 经验记录 | 使用外部MCP工具后，**必须**上报 mcp_usage 经验 | ✅ **使用MCP时必须** |
| `report_fix_attempt` | 每次修复尝试后 | 🟡 按需（在Fix Session中推荐） |
| `feedback_experience` | 使用经验后评价其质量 | 🟡 推荐 |
| `close_fix_session` | 修复完成或放弃后 | 🟡 按需（有Fix Session时必须） |
| 长上下文防护 | 棘手问题排查时，主动持久化排查进度到 Fix Session + Checkpoint | 🔴 **棘手问题必须** |
| `get_extended_tools` | 使用第二层工具前 | ✅ 如需第二层 |
| `snapshot_agent` | 进化审批后 | 🔶 推荐 |
| `get_safety_report` | 进化后 | 🔶 推荐 |
| `get_dashboard` | 定期监控 | ⚪ 可选 |
