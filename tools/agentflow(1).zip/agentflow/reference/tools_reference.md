# AgentFlow MCP 工具参数参考

## 概述

本文档提供了全部 38 个 AgentFlow MCP 工具的完整参数定义。工具按模块和层级组织。

- **第一层**：连接 AgentFlow MCP 服务器后即可使用
- **第二层**：需要先调用 `get_extended_tools` 激活

---

## 目标模块（Goal）

### create_goal（第一层）

创建新目标，支持阶段划分和层级关系。

**输入参数：**
```json
{
  "title": "字符串（必填）— 目标标题",
  "description": "字符串（必填）— 详细描述",
  "priority": "整数 1-10（默认5）— 数值越高越重要",
  "phases": ["字符串 — 阶段列表"],
  "parent_goal_id": "字符串 — 父目标ID，创建子目标时使用",
  "tags": ["字符串 — 标签列表"]
}
```

**注解：** `readOnlyHint: false`, `destructiveHint: false`

### update_goal（第一层）

更新目标字段（标题、状态、优先级、进度等）。

**输入参数：**
```json
{
  "goal_id": "字符串（必填）",
  "fields": {
    "title": "字符串 — 新标题",
    "status": "pending|active|completed|cancelled",
    "priority": "整数 1-10",
    "progress": "数值 0-100",
    "description": "字符串 — 新描述"
  }
}
```

### delete_goal（第一层）

删除目标。**需要安全确认。**

**输入参数：**
```json
{
  "goal_id": "字符串（必填）",
  "cascade": "布尔值 — 是否级联删除子目标",
  "confirm": "字符串（必填）— 必须为 'CONFIRM_DELETE'"
}
```

**注解：** `destructiveHint: true`

### get_goal（第一层）

获取目标详情，包含子目标树和进度。

**输入参数：**
```json
{
  "goal_id": "字符串（必填）",
  "depth": "整数（默认1）— 子目标树递归深度"
}
```

**注解：** `readOnlyHint: true`

### list_goals（第一层）

目标列表查询，支持多状态过滤、名称模糊搜索和分页。

**输入参数：**
```json
{
  "status": "pending|active|completed|cancelled — 按单状态过滤（兼容旧版）",
  "statuses": ["字符串 — 按多状态过滤（优先级高于status），如['active','pending']只返回进行中和待处理的目标"],
  "name": "字符串 — 按名称模糊搜索（不区分大小写）",
  "sort_by": "字符串 — 排序字段",
  "page": "整数（默认1）",
  "page_size": "整数（默认20）"
}
```

**注解：** `readOnlyHint: true`

---

## 任务模块（Task）

### create_tasks（第一层）

为目标批量创建任务。每个任务可指定技能类型、依赖关系和测试设计。

**输入参数：**
```json
{
  "goal_id": "字符串（必填）",
  "tasks": [
    {
      "title": "字符串（必填）— 任务标题",
      "description": "字符串（必填）— 任务描述",
      "skill_type": "go_crud|api_design|auth_security|db_storage|testing|code_review",
      "difficulty": "整数 1-10（默认5）— 任务难度评分。1-3简单 4-6中等 7-9困难 10极难",
      "phase": "字符串 — 所属目标阶段",
      "dependencies": ["任务ID或任务标题 — 必须先完成的前置任务（支持跨目标引用）"],
      "prerequisites": ["字符串 — 软约束前提条件（如'数据库表已创建'、'配置文件已存在'）。注入上下文供Agent确认，系统不强制校验"],
      "estimated_tokens": "整数 — 预估Token消耗",
      "test_design": {
        "unit_tests": ["字符串 — 单元测试"],
        "integration_tests": ["字符串 — 集成测试"],
        "acceptance_criteria": ["字符串 — 验收标准"]
      }
    }
  ]
}
```

**依赖解析规则：**
- 依赖可以引用 `task_id`（如 `task_xxxx`）或任务标题（字符串）
- 标题引用会自动解析为任务ID（优先搜索同批次，再全局搜索）
- 系统在创建前执行**循环依赖检测（DFS）** — 循环依赖会被拒绝
- 依赖未满足时，错误信息会包含具体的阻塞任务名称及其当前状态

### claim_task（第一层）

原子领取任务。不指定 `task_id` 时支持智能派发。**如果Agent之前有被中断的任务，会自动恢复并携带检查点数据。**

**✅ 核心改进：** 领取成功时自动编译并返回精准上下文（`compiled_context` 字段），通过7级管线编译，无需额外调用 `get_task_context`。

**🔴 领取优先级：** interrupted > failed > blocked > pending。**绝对禁止领取 running 状态的任务。**

**🔢 难度匹配：** 智能派发时会考虑任务 `difficulty` 与Agent能力的匹配度。优先领取难度适中的任务。

**输入参数：**
```json
{
  "agent_id": "字符串（必填）— Agent标识",
  "task_id": "字符串 — 不填则智能派发（会考虑难度匹配）",
  "skill_types": ["字符串 — 按技能类型过滤（智能派发时使用）"],
  "max_difficulty": "整数 1-10 — Agent可处理的最大难度（0或不填表示不限制）",
  "strict_skill": "布尔值（默认false）— 严格模式：true时仅领取skill_types匹配的任务，false时优先匹配但不限制"
}
```

**响应包含 `compiled_context` 和 `heartbeat_hint`：**
```json
{
  "result": { "...任务详情..." },
  "compiled_context": "\n=== 全局规则 ===\n...\n=== Skill DNA ===\n...\n=== 相关经验 ===\n...",
  "context_tokens": 1850,
  "heartbeat_hint": {
    "soft_timeout_seconds": 1500,
    "hard_timeout_seconds": 1800,
    "message": "⚠️ 请定期调用 update_task_progress 或 save_checkpoint（建议每5-10分钟一次）以维持心跳。30分钟无任何MCP工具调用将导致任务被中断。"
  }
}
```

**`compiled_context` 包含（可用时）：**
- 全局编码规则和项目约定
- 此任务类型的技能DNA规则、反模式和最佳实践
- 类似历史任务的经验教训
- 依赖任务的摘要
- 最近的进化日志

**⚠️ 心跳警告：** 看门狗会在 `soft_timeout_seconds`（25分钟）静默后记录警告，在 `hard_timeout_seconds`（30分钟）后将任务标记为 `interrupted`。任何MCP工具调用都会自动续期心跳。

**恢复行为：**
当未指定 `task_id` 且Agent有之前被中断的任务时：
- 被中断的任务会自动恢复（interrupted → running）
- 响应包含 `resumed: true` 和 `resume_info`（含之前的进度）
- 如果保存过检查点，`checkpoint` 字段包含已完成/待完成项和已修改文件
- 恢复的任务同样会提供 `compiled_context`
- Agent应根据检查点数据从中断处继续

### report_task_result（第一层）

汇报任务完成/失败。自动触发摘要压缩 → 记忆创建 → 经验提取 → 模式检测。

**✅ 核心改进：** 响应包含 `experience_hint` 字段，智能引导你是否需要调用 `report_experience`。

**输入参数：**
```json
{
  "task_id": "字符串（必填）",
  "agent_id": "字符串（必填）",
  "status": "completed|failed|blocked（必填）",
  "summary": "字符串（必填）— ≤200字，超出会被截断",
  "key_decisions": ["字符串 — 做出的关键决策"],
  "code_output": "字符串 — 产出的代码成果",
  "test_results": {
    "passed": ["字符串 — 通过的测试"],
    "failed": ["字符串 — 失败的测试"],
    "coverage": "数值 — 0-100 覆盖率百分比"
  },
  "tokens_used": "整数 — Token消耗量",
  "self_reflection": "字符串 — 自我反思，可以改进什么"
}
```

**响应包含 `experience_hint`：**
```json
{
  "confirm": "reported",
  "goal_progress": 33.3,
  "next_recommendation": "claim next task",
  "experience_hint": "✅ 任务完成。仅在发现通用性的坑、陷阱或高效模式时才需要调用 report_experience..."
}
```

**`experience_hint` 引导规则：**

| 任务状态 | 引导内容 |
|----------|----------|
| `failed` | 强烈建议上报负经验（必须含 root_cause + solution） |
| `blocked` | 如涉及通用问题建议上报 |
| `completed` | 仅在发现坑/陷阱/高效模式时上报，常规操作无需上报 |

### release_task（第一层）

释放已领取的任务，归还到待处理队列。

**输入参数：**
```json
{
  "task_id": "字符串（必填）",
  "agent_id": "字符串（必填）",
  "reason": "字符串（必填）— 释放原因"
}
```

### get_task_detail（第一层）

获取任务详情，包含测试设计、产出物和执行历史。

**输入参数：**
```json
{
  "task_id": "字符串（必填）"
}
```

**注解：** `readOnlyHint: true`

### update_task（第一层）

修改任务字段，带验证。支持状态迁移（自动队列移动）、依赖更新、优先级验证和测试设计变更。只读字段（id、created_at、completed_at、claimed_by、tokens_used、retry_count）不可修改。

**输入参数：**
```json
{
  "task_id": "字符串（必填）",
  "fields": {
    "title": "字符串 — 任务标题",
    "description": "字符串 — 任务描述",
    "priority": "整数 1-10 — 数值越高越重要",
    "skill_type": "字符串 — go_crud|api_design|auth_security|db_storage|testing|code_review",
    "difficulty": "整数 1-10 — 任务难度评分（1-3简单 4-6中等 7-9困难 10极难）",
    "phase": "字符串 — 所属目标阶段",
    "status": "pending|running|completed|failed|blocked|interrupted — 状态变更自动处理队列迁移和锁释放",
    "dependencies": ["字符串 — 必须先完成的任务ID"],
    "prerequisites": ["字符串 — 软约束前提条件"],
    "test_design": {
      "unit_tests": ["字符串"],
      "integration_tests": ["字符串"],
      "acceptance_criteria": ["字符串"]
    },
    "estimated_tokens": "整数 ≥ 0 — 预估Token消耗"
  }
}
```

**验证规则：**
- `priority`：必须在1-10之间，超出范围会被拒绝
- `status`：变更会触发自动队列迁移（如 pending→running 会从待处理队列移到运行队列，离开running状态时释放锁）
- `dependencies`/`prerequisites`：必须是字符串数组，序列化为JSON
- `test_design`：必须是有效对象，包含可选的 unit_tests/integration_tests/acceptance_criteria
- 只读字段：`id`、`created_at`、`completed_at`、`claimed_by`、`tokens_used`、`retry_count` — 尝试修改会返回错误
- 未知字段也会被拒绝，错误信息会列出所有允许的字段

**响应：**
```json
{
  "status": "updated",
  "task_id": "task_xxxx",
  "task": { "...完整任务对象..." }
}
```

### list_tasks（第一层）

查询任务列表，支持多维过滤、聚合统计和分页。

**输入参数：**
```json
{
  "goal_id": "字符串 — 按目标ID过滤，查看该目标下所有子任务",
  "parent_task_id": "字符串 — 按父任务ID过滤，查看某任务拆分出的子任务",
  "status": "pending|running|completed|failed|blocked|interrupted|review — 按单状态过滤（兼容旧版）",
  "statuses": ["字符串 — 多状态过滤（优先级高于status），如['pending','running','blocked']查所有未完成任务"],
  "exclude_status": ["字符串 — 排除指定状态，如['completed']排除已完成任务"],
  "skill_type": "字符串 — 按Skill类型过滤",
  "claimed_by": "字符串 — 按领取者Agent ID过滤",
  "min_difficulty": "整数 1-10 — 最低难度过滤",
  "max_difficulty": "整数 1-10 — 最高难度过滤",
  "keyword": "字符串 — 按标题或描述关键词搜索（不区分大小写）",
  "group_by": "skill_type|status|phase — 聚合统计维度（返回分组计数而非任务列表）",
  "page": "整数（默认1）",
  "page_size": "整数（默认20）"
}
```

**注解：** `readOnlyHint: true`

### update_task_progress（第一层）

更新任务执行进度（0-100）。仅当前领取者可更新。**此调用同时隐式续期Agent心跳**，防止看门狗将任务标记为中断。

**输入参数：**
```json
{
  "task_id": "字符串（必填）",
  "agent_id": "字符串（必填）",
  "progress": "数值 0-100（必填）",
  "message": "字符串 — 进度描述"
}
```

**💡 心跳提示：** 对于长时间运行的任务，即使进度没有明显变化也建议每2-3分钟调用一次。这能保持心跳存活，防止看门狗中断你的任务。

### save_checkpoint（第一层）

保存任务执行检查点。**对于崩溃恢复和心跳续期至关重要。** 执行大型任务的Agent应定期保存检查点。如果Agent意外终止，下次 `claim_task` 调用会自动恢复检查点。

**输入参数：**
```json
{
  "task_id": "字符串（必填）",
  "agent_id": "字符串（必填）",
  "completed_items": ["字符串 — 已完成的步骤"],
  "pending_items": ["字符串 — 待完成的步骤"],
  "modified_files": ["字符串 — 已修改的文件"],
  "notes": "字符串 — 当前进展备注"
}
```

**最佳实践：** 每3-5个子步骤或每次重大文件修改后保存一次检查点。有两个作用：
1. **崩溃恢复** — 如果会话丢失，下一个Agent可以从检查点恢复
2. **心跳续期** — 防止看门狗在长时间操作期间标记任务为中断

### split_task（第一层）

将当前领取的任务拆分为多个子任务（孙任务）。只有任务的当前领取者才能拆分。拆分后父任务保持running状态，当所有子任务完成后父任务自动完成。子任务继承父任务的goal_id和phase。

**输入参数：**
```json
{
  "parent_task_id": "字符串（必填）— 要拆分的父任务ID（必须是你当前领取的任务）",
  "agent_id": "字符串（必填）— Agent标识（必须与父任务的领取者一致）",
  "subtasks": [
    {
      "title": "字符串（必填）— 子任务标题",
      "description": "字符串（必填）— 子任务描述",
      "skill_type": "字符串 — 不填则继承父任务",
      "difficulty": "整数 1-10（默认5）— 难度评分",
      "phase": "字符串 — 不填则继承父任务",
      "dependencies": ["字符串 — 子任务间的依赖（支持标题引用）"],
      "prerequisites": ["字符串 — 执行前提条件"],
      "estimated_tokens": "整数 — 预估Token消耗",
      "test_design": {
        "unit_tests": ["字符串"],
        "integration_tests": ["字符串"],
        "acceptance_criteria": ["字符串"]
      }
    }
  ]
}
```

---

## 上下文模块（Context）

### get_task_context（第一层）

通过7级管线为任务编译精准上下文。返回全局规则、Skill DNA、依赖摘要、历史经验和进化日志。

**输入参数：**
```json
{
  "task_id": "字符串（必填）",
  "budget": "整数 1200-4000（默认2000）— Token预算",
  "detail_level": "minimal|standard|full（默认standard）"
}
```

**注解：** `readOnlyHint: true`

**详细度编译策略：**

| 级别 | 编译层级 | 约Token数 | 使用场景 |
|------|---------|----------|---------|
| `minimal` | L1(全局规则) + L3(任务描述) + L4(Skill DNA) | 400-800 | 简单CRUD、小修复 |
| `standard` | L1 + L2(技术栈) + L3 + L4 + L5(依赖) + L6(经验) | 1200-2000 | 标准开发任务 |
| `full` | L1 + L2 + L3 + L4 + L5 + L6 + L7(进化日志) | 2000-4000 | 复杂架构、多模块任务 |

**使用建议：**
- 简单任务：`minimal` + budget 1200 → 比standard节省50%+ Token
- 标准任务：`standard` + budget 2000
- 复杂架构：`full` + budget 4000

### get_global_rules（第一层）

获取全局规则列表（团队/项目级编码规范）。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

### get_artifact（第一层）

获取代码产出物，支持配置提取模式。

**输入参数：**
```json
{
  "file_path": "字符串（必填）— 文件路径",
  "extract_mode": "full|interfaces_only|summary（默认full）— 完整/仅接口/摘要"
}
```

**注解：** `readOnlyHint: true`

### search_context（第一层）

语义搜索项目上下文（决策、摘要、经验）。

**输入参数：**
```json
{
  "query": "字符串（必填）— 搜索关键词",
  "scope": "all|decisions|summaries|experiences（默认all）— 搜索范围",
  "limit": "整数（默认10）— 返回数量限制"
}
```

**注解：** `readOnlyHint: true`

### get_memory_status（第二层）

查看记忆状态：片段数量、容量、衰减率、热点。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

---

## 技能模块（Skill）

### get_skill（第一层）

获取技能详情，包含DNA和效能指标。

**输入参数：**
```json
{
  "name": "字符串（必填）— 技能名称",
  "version": "整数 — 指定版本号，默认最新"
}
```

**注解：** `readOnlyHint: true`

### list_skills（第一层）

列出所有技能及效能摘要。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

### create_skill（第二层）

创建新技能，包含DNA定义。

**输入参数：**
```json
{
  "name": "字符串（必填）— 技能名称",
  "description": "字符串（必填）— 技能描述",
  "dna": {
    "rules": ["字符串 — 规则，≤20条"],
    "template": "字符串 — 代码模板",
    "checklist": ["字符串 — 质量检查清单"],
    "anti_patterns": ["字符串 — 反模式，≤15条"],
    "best_practices": ["字符串 — 最佳实践，≤15条"],
    "context_hints": ["字符串 — 上下文关注点"]
  },
  "tags": ["字符串 — 标签"]
}
```

### update_skill（第二层）

更新技能DNA。自动创建版本并检测是否需要提炼。

**输入参数：**
```json
{
  "name": "字符串（必填）— 技能名称",
  "changes": {
    "rules_add": ["字符串 — 新增规则"],
    "rules_remove": ["字符串 — 删除规则"],
    "template": "字符串 — 新代码模板",
    "checklist_add": ["字符串 — 新增检查项"],
    "anti_patterns_add": ["字符串 — 新增反模式"],
    "best_practices_add": ["字符串 — 新增最佳实践"]
  },
  "reason": "字符串（必填）— 更新原因"
}
```

---

## 进化模块（Evolution）

### report_experience（第一层）

任务完成后上报正面或负面经验。系统自动聚合并触发模式检测。

**⚡ 加权评分：** 经验使用 `severity × confidence` 加权评分。高严重度+高置信度的经验能更快触发进化（如2条critical经验可能足够，而minor需要5条+）。

**输入参数：**
```json
{
  "task_id": "字符串（必填）— 关联任务ID",
  "type": "positive|negative（必填）— 经验类型",
  "skill_type": "字符串（必填）— 关联技能名称",
  "category": "pattern|technique|architecture|bug|performance|security|design_flaw（必填）",
  "description": "字符串（必填）— ≥50字符，清晰描述",
  "root_cause": "字符串 — 根因分析（负面经验必填）",
  "solution": "字符串 — 解决方案（负面经验必填）",
  "code_example": "字符串 — 代码示例（可选）",
  "severity": "critical|major|minor — 影响进化触发权重（critical=2x, major=1.5x, minor=0.5x）",
  "confidence": "数值 0-1 — 影响进化触发权重",
  "fix_session_id": "字符串 — 关联的Fix Session ID（可选）"
}
```

### query_fix_experience（第一层）

查询问题修复经验。自动创建或关联 Fix Session，返回历史相关经验（含反馈标注和有效可信度）、已尝试方案（防死循环）和探索建议。

**输入参数：**
```json
{
  "problem": "字符串（必填）— 问题描述，越详细越好，用于语义匹配",
  "error_type": "compile|runtime|logic|test|config|other — 错误分类",
  "error_msg": "字符串 — 原始错误信息",
  "task_id": "字符串 — 关联任务ID（可选）",
  "session_id": "字符串 — Fix Session ID（首次不传会自动创建，后续调用必须携带）"
}
```

**⚠️ 关键规则：**
- 首次调用会创建 Fix Session，返回 `session_id`
- 后续所有调用必须携带 `session_id` 保持同一会话

### report_fix_attempt（第一层）

记录一次修复尝试。系统自动进行防死循环检测（L2相似度检测+L3强制拦截）。

**输入参数：**
```json
{
  "session_id": "字符串（必填）— Fix Session ID",
  "approach": "字符串（必填）— 方案描述（做了什么）",
  "reasoning": "字符串 — 推理过程（为什么这么做）",
  "result": "success|failed|partial|unknown（必填）— 本次尝试结果",
  "result_detail": "字符串 — 结果详情",
  "code_changes": "字符串 — 关键代码变更摘要",
  "modified_files": ["字符串 — 修改的文件列表"],
  "error_after": "字符串 — 修改后的新错误（如有）",
  "confidence": "数值 0-1 — 对本次尝试的信心度",
  "previous_attempt_helped": "字符串 — 之前哪个尝试对本次有帮助"
}
```

### feedback_experience（第一层）

对经验质量进行反馈。支持正向（helpful）和负面反馈。负面反馈累计≥3次将触发经验拉黑。

**输入参数：**
```json
{
  "experience_id": "字符串（必填）— 经验ID",
  "feedback_type": "helpful|negative|misleading|irrelevant|outdated（必填）",
  "negative_tags": ["字符串 — 负面词标签（负面反馈时必填，多选）"],
  "reason": "字符串 — 反馈原因说明",
  "mismatch_detail": "字符串 — 不匹配的具体表现",
  "session_id": "字符串 — 当前Fix Session ID（可选）"
}
```

**负面词标签（negative_tags）：**

| 标签 | 含义 |
|------|------|
| `not_applicable` | 不适用于当前场景 |
| `misleading` | 误导性，按照经验操作引入新问题 |
| `outdated` | 已过时，API/库/框架版本不再适用 |
| `too_vague` | 太笼统，缺乏可操作细节 |
| `wrong_root_cause` | 根因分析不正确 |
| `partial_match` | 只解决了问题的一部分 |
| `duplicate_effort` | 导致不必要的额外工作 |
| `context_mismatch` | 上下文与当前环境差异大 |

### update_fix_attempt_label（第一层）

更新修复尝试的标记。标记影响最终经验的提炼质量。

**输入参数：**
```json
{
  "session_id": "字符串（必填）— Fix Session ID",
  "attempt_id": "字符串（必填）— 尝试ID（如 attempt_1）",
  "label": "exploring|promising|dead_end|correct|stepping_stone（必填）",
  "label_reason": "字符串 — 标记原因说明"
}
```

**标记类型说明：**

| 标记 | 含义 | 对经验提炼的影响 |
|------|------|-----------------|
| `exploring` | 探索中（默认） | 不纳入最终经验 |
| `promising` | 有前景 | 作为参考方案 |
| `dead_end` | 死路 | 纳入 dead_ends（警告后人避开） |
| `correct` | 正确方案 | 纳入 fix_path（最终解决路径） |
| `stepping_stone` | 铺垫步骤 | 标记为前置准备步骤 |

### close_fix_session（第一层）

关闭 Fix Session。resolved 时自动提炼最终经验（fix_path + dead_ends + key_insight）并写入正式经验流。

**输入参数：**
```json
{
  "session_id": "字符串（必填）— Fix Session ID",
  "status": "resolved|abandoned（必填）— 关闭状态",
  "resolution": "字符串 — 解决方案摘要（resolved时必填）",
  "root_cause": "字符串 — 根因分析（可选，不填则自动提取）",
  "key_insight": "字符串 — 关键洞察（可选，帮助后续Agent快速定位）",
  "abandon_reason": "字符串 — 放弃原因（abandoned时填写）"
}
```

### get_evolution_status（第一层）

查看进化状态和待处理提案。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

### get_experiences（第二层）

获取经验列表，支持过滤。

**输入参数：**
```json
{
  "skill_type": "字符串 — 按技能过滤",
  "category": "字符串 — 按分类过滤",
  "type": "positive|negative — 按类型过滤",
  "limit": "整数 — 返回数量限制"
}
```

**注解：** `readOnlyHint: true`

### approve_evolution（第二层）

审批、拒绝或修改进化提案。

**输入参数：**
```json
{
  "evo_id": "字符串（必填）— 进化提案ID",
  "action": "approve|reject|modify（必填）— 操作类型",
  "modification": "字符串 — action=modify 时必填，修改内容"
}
```

### trigger_evolution（第二层）

手动触发进化分析。

**输入参数：**
```json
{
  "scope": "skill|rules|strategy|all（默认all）— 进化范围",
  "target": "字符串 — 技能名称或 'global'",
  "force": "布尔值（默认false）— 是否强制触发"
}
```

### snapshot_agent（第二层）

保存当前Agent状态到Archive（SICA核心）。在里程碑或成功进化后使用，便于回滚。

**输入参数：**
```json
{
  "trigger": "manual|milestone|auto（默认manual）— 触发方式",
  "note": "字符串 — 快照描述"
}
```

### distill_and_evolve（第一层）

Agent主动触发特定Skill的经验提炼和进化。功能：
1. 汇总目标Skill的所有累积经验
2. 去重整理模式（语义去重）
3. 生成**加权评分**的进化提案（severity × confidence，非简单计数）
4. 低影响提案自动应用；高影响提案进入**灰度验证**
5. 清理Skill DNA中的陈旧/重复规则

**灰度发布：** 启用时（默认），高影响进化提案（impact ≥ 0.5）不会立即全局应用：
- 创建candidate版本与stable版本并存
- 20%的任务使用candidate版本进行验证
- 积累最少5个样本后：成功率 ≥ 95% → 自动晋升；< 90% → 自动回滚
- 防止一次错误进化影响所有任务

**使用时机：** 完成3-5个任务后，或发现Skill DNA可能过时时。

**输入参数：**
```json
{
  "skill_type": "字符串（必填）— 目标Skill名称",
  "auto_apply": "布尔值（默认true）— 是否自动应用低影响提案",
  "include_stale": "布尔值（默认true）— 是否清理陈旧/重复规则",
  "max_proposals": "整数（默认5）— 最多生成提案数"
}
```

**响应示例：**
```json
{
  "skill_type": "go_crud",
  "experiences_analyzed": 15,
  "patterns_detected": 3,
  "proposals_generated": 3,
  "proposals_applied": 2,
  "proposals_pending": 1,
  "stale_rules_removed": 1,
  "duplicates_removed": 2,
  "proposals": [
    {
      "category": "bug",
      "evidence_count": 5,
      "impact": 0.3,
      "status": "applied"
    },
    {
      "category": "architecture",
      "evidence_count": 3,
      "impact": 0.7,
      "status": "pending_approval",
      "evo_id": "evo_distill_xxx"
    }
  ],
  "summary": "Skill go_crud 提炼完成: 分析15条经验, 检测到3个模式, 生成3个提案(已应用2/待审批1)..."
}
```

### audit_skill_quality（第一层）

Agent主动审核Skill DNA质量，检测幻觉产生的低质量规则、重复、冲突和无支撑内容。**对维护进化质量至关重要。**

**五个审计维度：**
1. **重复检测** — 查找内容相同或高度相似的规则
2. **模糊性检测** — 标记过短/过泛的规则，缺乏可操作指导
3. **冲突检测** — 检测 anti_patterns 和 best_practices 之间的矛盾
4. **膨胀检测** — 规则数量接近硬性限制时发出警告
5. **证据支撑检查** — 检查进化规则是否有经验支撑（捕获幻觉）

**使用时机：** 任何进化事件后，或定期（每10-15个任务）维护DNA质量时。

**输入参数：**
```json
{
  "skill_name": "字符串（必填）— 目标Skill名称",
  "auto_fix": "布尔值（默认false）— 是否自动修复重复等可修复问题"
}
```

**响应示例：**
```json
{
  "skill_name": "go_crud",
  "version": 5,
  "overall_health": "needs_attention",
  "total_issues": 4,
  "critical_count": 1,
  "warning_count": 2,
  "info_count": 1,
  "issues": [
    {
      "severity": "critical",
      "category": "conflict",
      "description": "anti_patterns[2] 与 best_practices[1] 内容矛盾(相似度78%): ...",
      "suggestion": "检查这两条规则，保留正确的一条",
      "auto_fixable": false
    },
    {
      "severity": "warning",
      "category": "unsupported",
      "description": "rules[8] 缺乏经验证据支撑，可能是幻觉产生: ...",
      "suggestion": "审查该规则是否合理",
      "auto_fixable": false
    }
  ],
  "auto_fixed": 0,
  "dna_stats": { "rules": 12, "anti_patterns": 5, "best_practices": 8 },
  "evidence_check": { "total_experiences": 15, "unsupported_rules": 2, "status": "checked" },
  "recommendation": "发现 1 个严重问题，建议立即修复或回滚到上一个健康版本"
}
```

### list_experiences（第一层）

分批获取经验列表，支持游标分页和多维过滤。用于Agent迭代审查和清理经验库。

**输入参数：**
```json
{
  "type": "positive|negative（必填）— 经验类型",
  "skill_type": "字符串 — 按Skill类型过滤",
  "category": "字符串 — 按类别过滤",
  "keyword": "字符串 — 按描述关键词搜索",
  "cursor": "字符串 — 分页游标（首次不传，后续传入上一次返回的cursor）",
  "batch_size": "整数（默认20，最大50）— 每批数量"
}
```

**返回包含：**
- `experiences` — 经验列表
- `cursor` — 下一页游标
- `has_more` — 是否有更多数据

### delete_experiences（第一层）

批量删除指定经验。⚠️ 删除不可撤销，建议先用 `list_experiences` 确认后再删除。

**输入参数：**
```json
{
  "type": "positive|negative（必填）— 经验类型",
  "ids": ["字符串 — 要删除的经验ID列表（从list_experiences获取）"],
  "confirm": "字符串（必填）— 必须为 'CONFIRM_DELETE' 才能执行删除"
}
```

**注解：** `destructiveHint: true`

---

## 反馈模块（Feedback）

### agent_complaint（第一层）

Agent吐槽功能。当对工具、经验、Skill规则、工作流程等感到不满时，记录吐槽和改进建议。高频吐槽自动触发进化提案。

**输入参数：**
```json
{
  "type": "experience|tool|skill|workflow|context|performance|other（必填）— 吐槽类型",
  "severity": "minor|frustrating|blocking（必填）— minor=轻微不爽, frustrating=令人沮丧, blocking=严重阻塞",
  "complaint": "字符串（必填）— 吐槽内容，详细描述不满和问题",
  "suggestion": "字符串 — 改进建议",
  "related_task_id": "字符串 — 关联任务ID",
  "related_skill": "字符串 — 关联Skill名称",
  "related_tool": "字符串 — 关联工具名",
  "agent_id": "字符串 — Agent标识"
}
```

**返回包含：**
- `complaint_id` — 吐槽记录ID
- `similar_complaints` — 同维度吐槽数量
- `auto_evolution_hint` — 当同维度高严重度吐槽≥3次时，提示触发进化

### get_complaint_stats（第一层）

获取Agent吐槽统计。按类型/严重程度/工具/Skill聚合，展示高频吐槽热点。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

---

## 安全模块（Safety）

### get_safety_report（第二层）

五维安全报告 + 人工校准状态。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

### rollback_to_archive（第二层）

紧急回滚到历史最佳配置。**需要安全确认。**

**输入参数：**
```json
{
  "archive_id": "字符串 — 不填则回滚到最高分Archive",
  "scope": "all|rules|skill:{名称}（默认all）— 回滚范围",
  "confirm": "字符串（必填）— 必须为 'CONFIRM_ROLLBACK'"
}
```

**注解：** `destructiveHint: true`

---

## 仪表盘模块（Dashboard）

### get_dashboard（第一层）

全局仪表盘，包含目标/任务/技能/进化/Token概览。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

### get_health_check（第一层）

系统健康检查：Redis、SQLite、锁、僵尸任务。

**输入参数：**
```json
{}
```

**注解：** `readOnlyHint: true`

### get_token_analytics（第二层）

详细Token消耗分析。

**输入参数：**
```json
{
  "period": "today|week|month（默认today）— 统计周期"
}
```

**注解：** `readOnlyHint: true`

---

## 内置工具

### get_extended_tools

动态激活第二层扩展工具。返回工具总数和分层统计。

**输入参数：**
```json
{}
```

**说明：** 如果需要使用任何第二层功能，在会话开始时调用一次即可。

---

## 🗂️ Project 管理工具

> 这些工具用于 Project Lifecycle 管理，通过 Dashboard HTTP API 调用（非 MCP 工具）。
> Agent 通过 `fetch('/api/projects/...')` 调用，人类通过 Dashboard 界面操作。

### create_project

创建新项目，自动初始化所有阶段的 PhaseGate。

**HTTP：** `POST /api/projects`

**请求体：**
```json
{
  "title": "字符串（必填）— 项目标题",
  "description": "字符串（必填）— 项目描述",
  "priority": "整数（1-10，默认5）— 优先级",
  "tags": ["字符串 — 标签列表"]
}
```

**返回：**
```json
{
  "id": "字符串 — 项目ID（格式：proj_xxx）",
  "title": "字符串",
  "description": "字符串",
  "current_phase": "idea",
  "status": "draft",
  "priority": 5,
  "tags": [],
  "created_at": "RFC3339时间戳"
}
```

---

### list_projects

获取项目列表，支持状态过滤和分页。

**HTTP：** `GET /api/projects?status=&page=&page_size=`

**查询参数：**
```
status     字符串（可选）— 过滤状态：draft/active/completed/archived
page       整数（默认1）— 页码
page_size  整数（默认20）— 每页数量
```

**返回：**
```json
{
  "projects": [{ "id": "...", "title": "...", "current_phase": "...", "status": "..." }],
  "total": 42,
  "page": 1,
  "page_size": 20
}
```

---

### get_project_overview

获取项目完整概览，包含所有阶段状态和进度。

**HTTP：** `GET /api/projects/{projectID}/overview`

**返回：**
```json
{
  "project": { "id": "...", "title": "...", "current_phase": "mvp" },
  "phases": [
    {
      "name": "idea",
      "status": "approved",
      "approved_by": "human",
      "approved_at": "...",
      "progress": { "total_goals": 2, "completed_goals": 2, "percentage": 100 }
    }
  ]
}
```

---

### get_phase_overview

获取指定阶段的详细概览，包含 Goal 列表、准出条件和审批状态。

**HTTP：** `GET /api/projects/{projectID}/phases/{phaseName}/overview`

**路径参数：**
```
projectID  字符串（必填）— 项目ID
phaseName  字符串（必填）— 阶段名称：idea/macro/research/mvp/p1/p2
```

**返回：**
```json
{
  "project_id": "proj_xxx",
  "phase_name": "idea",
  "gate_status": "pending",
  "progress": {
    "total_goals": 3,
    "completed_goals": 1,
    "total_tasks": 10,
    "completed_tasks": 4,
    "percentage": 40.0
  },
  "goals": [
    {
      "goal_id": "goal_xxx",
      "title": "项目蓝图",
      "status": "completed",
      "tasks": [{ "task_id": "task_xxx", "title": "...", "status": "completed" }]
    }
  ],
  "exit_conditions": [
    {
      "description": "项目蓝图文档已完成",
      "is_met": true,
      "bound_task_id": "task_xxx",
      "bound_goal_id": ""
    }
  ],
  "unmet_conditions": ["条件描述..."],
  "approved_by": "",
  "reject_comment": ""
}
```

---

### submit_phase_review

提交阶段审阅，将阶段产出物和总结提交给人类审批。

**HTTP：** `POST /api/projects/{projectID}/phases/{phaseName}/submit`

**请求体：**
```json
{
  "deliverables": [
    {
      "name": "字符串（必填）— 产出物名称",
      "description": "字符串 — 产出物描述",
      "is_completed": true
    }
  ],
  "summary": "字符串（必填）— 阶段总结（建议100字以上）"
}
```

**返回：** 更新后的 PhaseGate 对象（status 保持 pending）

---

### approve_phase

审批通过指定阶段，项目自动推进到下一阶段。

**HTTP：** `POST /api/projects/{projectID}/gates/{phaseName}/approve`

**请求体：**
```json
{
  "comment": "字符串（必填）— 审批意见",
  "approved_by": "字符串（必填）— 审批人标识（如 'human' 或用户名）"
}
```

**返回：** 更新后的 Project 对象（current_phase 已推进）

---

### reject_phase

驳回指定阶段，Agent 需要重新完成该阶段工作后再次提交。

**HTTP：** `POST /api/projects/{projectID}/gates/{phaseName}/reject`

**请求体：**
```json
{
  "comment": "字符串（必填）— 驳回原因",
  "revision_items": ["字符串 — 具体修订要点（建议逐条列出）"]
}
```

**返回：** 更新后的 PhaseGate 对象（status = rejected）

---

### request_revision

请求修订，Agent 需要按照修订要点修改后重新提交（不需要重做整个阶段）。

**HTTP：** `POST /api/projects/{projectID}/gates/{phaseName}/revise`

**请求体：**
```json
{
  "comment": "字符串（必填）— 修订说明",
  "revision_items": ["字符串 — 具体修订要点"]
}
```

**返回：** 更新后的 PhaseGate 对象（status = revision_requested）

---

### get_phase_feedback

获取指定阶段最近一次审批的反馈内容（驳回/修订时的意见）。

**HTTP：** `GET /api/projects/{projectID}/phases/{phaseName}/feedback`

**返回：**
```json
{
  "phase_name": "idea",
  "action": "rejected",
  "comment": "内容不完整",
  "revision_items": ["补充风险分析", "明确技术约束"],
  "reviewed_by": "human",
  "reviewed_at": "RFC3339时间戳"
}
```

---

### link_goal_to_phase

手动将 Goal 关联到 Project 的指定阶段，用于进度追踪。

**HTTP：** `POST /api/projects/{projectID}/phases/{phaseName}/link-goal`

**请求体：**
```json
{
  "goal_id": "字符串（必填）— 要关联的 Goal ID"
}
```

**返回：**
```json
{
  "project_id": "proj_xxx",
  "phase_name": "idea",
  "goal_id": "goal_xxx",
  "linked_at": "RFC3339时间戳"
}
```

---

### link_task_to_phase

手动将 Task 关联到 Project 的指定阶段（需同时指定所属 Goal）。

**HTTP：** `POST /api/projects/{projectID}/phases/{phaseName}/link-task`

**请求体：**
```json
{
  "goal_id": "字符串（必填）— Task 所属的 Goal ID",
  "task_id": "字符串（必填）— 要关联的 Task ID"
}
```

---

### bind_condition_to_task

将准出条件绑定到具体的 Task 或 Goal，实现自动完成检查。

**HTTP：** `POST /api/projects/{projectID}/phases/{phaseName}/bind-condition`

**请求体：**
```json
{
  "condition_index": "整数（必填）— 准出条件的索引（从0开始）",
  "task_id": "字符串（可选）— 绑定到 Task ID",
  "goal_id": "字符串（可选）— 绑定到 Goal ID（task_id 和 goal_id 至少填一个）"
}
```

**说明：** 绑定后，当对应 Task/Goal 完成时，准出条件自动标记为 `is_met = true`。

---

### get_pending_approvals_count

获取当前待审批的阶段数量（用于 Dashboard 徽章显示）。

**HTTP：** `GET /api/projects/pending-approvals`

**返回：**
```json
{
  "count": 3
}
```

---

### get_phase_history

获取项目所有阶段的审批历史记录。

**HTTP：** `GET /api/projects/{projectID}/history`

**返回：**
```json
[
  {
    "phase_name": "idea",
    "action": "approved",
    "comment": "内容完整，通过",
    "reviewed_by": "human",
    "reviewed_at": "RFC3339时间戳"
  }
]
```